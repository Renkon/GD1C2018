CREATE SCHEMA EL_MONSTRUO_DEL_LAGO_MASER;
GO

-------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[clientes] -- 1
(
    id_cliente                      INT IDENTITY(0, 1) PRIMARY KEY,
    nombre_cliente                  NVARCHAR(255),
    apellido_cliente                NVARCHAR(255),
    id_tipo_documento               INT NOT NULL DEFAULT 6,
    numero_documento_cliente        NUMERIC(18,0) NOT NULL,
    correo_cliente                  NVARCHAR(255) NOT NULL UNIQUE,
    telefono_cliente                NVARCHAR(100),
    domicilio_calle_cliente         NVARCHAR(255),
    domicilio_numero_cliente        NUMERIC(18,0),
    domicilio_piso_cliente          NUMERIC(18,0),
    domicilio_departamento_cliente  NVARCHAR(50),
    ciudad_cliente                  NVARCHAR(255),
    id_pais                         INT,
    nacionalidad_cliente            NVARCHAR(20),
    fecha_nacimiento_cliente        DATETIME,
    estado_cliente                  BIT DEFAULT 1
    
    UNIQUE(id_tipo_documento, numero_documento_cliente)
);


-------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[cuentas] -- 2
(    
    id_usuario                 INT NOT NULL PRIMARY KEY,
    usuario_cuenta             NVARCHAR(255) NOT NULL UNIQUE,
    contraseña_cuenta          CHAR(64) NOT NULL,
    intentos_acceso_cuenta     NUMERIC(1,0) DEFAULT 0
);


-------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[tipos_documento] -- 3
(
    id_tipo_documento        INT IDENTITY(1, 1) PRIMARY KEY,
    nombre_tipo_documento    NVARCHAR(60) NOT NULL,
    sigla_tipo_documento     CHAR(3) NOT NULL
);


-------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[facturas] -- 4
(
    id_factura            INT IDENTITY(2396745, 1) PRIMARY KEY,
    fecha_factura         DATETIME NOT NULL,
    total_factura         NUMERIC(18,2),
    id_estadia            INT NOT NULL,
    id_forma_de_pago      INT NOT NULL,
    detalle_pago          NVARCHAR(1000)
);


-------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[formas_de_pago] -- 5
(
    id_forma_de_pago            INT IDENTITY(1, 1) PRIMARY KEY,
    descripcion_forma_de_pago   NVARCHAR(255) NOT NULL
);


-------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[consumos] -- 6
(
    id_consumo            INT IDENTITY (1, 1) PRIMARY KEY,
    id_consumible         INT NOT NULL,
    id_estadia            INT NOT NULL,
    id_habitacion         INT NOT NULL,
    fecha_consumo         DATETIME,
    cantidad_consumo      NUMERIC(18,0) NOT NULL
);


-------------------------------------------------------------------------------------------------------------------------------------------

CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[clientesXestadias] -- 7
(
    id_cliente INT NOT NULL,
    id_estadia INT NOT NULL
    
    PRIMARY KEY (id_cliente, id_estadia)
);


-------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[cierres_temporales_habitacion] -- 8
(
    id_cierre_temporales_habitacion            INT IDENTITY (1, 1) PRIMARY KEY,
    fecha_inicio_cierre_temporal_habitacion    DATETIME NOT NULL,
    fecha_fin_cierre_temporal_habitacion       DATETIME NOT NULL,
    id_habitacion                              INT NOT NULL,
    motivo_cierre_temporal_habitacion          NVARCHAR(2500) NOT NULL
);


-------------------------------------------------------------------------------------------------------------------------------------------
 CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[items_factura] -- 9
(
    id_item_factura                INT IDENTITY (1, 1) PRIMARY KEY,
    id_factura                     INT NOT NULL,
    id_consumo                     INT NULL,
    precio_unitario_item_factura   NUMERIC(18,2) NOT NULL,
    descripcion_item_factura       NVARCHAR(255) NOT NULL DEFAULT 'Desconocido',
    cantidad_item_factura          NUMERIC(18,0) NOT NULL
);


-------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[consumibles] -- 10
(
    id_consumible            INT IDENTITY (2324, 1) PRIMARY KEY,
    precio_consumible        NUMERIC(18,2) NOT NULL,
    descripcion_consumible   NVARCHAR(255) NOT NULL
);


-------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[estadias] -- 11
(
    id_estadia                INT IDENTITY (1, 1) PRIMARY KEY,
    id_reserva                INT NOT NULL,
    id_usuario_ingreso        INT NOT NULL,
    id_usuario_egreso         INT,
    fecha_ingreso_estadia     DATETIME NOT NULL,
    fecha_egreso_estadia      DATETIME,
    consumos_cerrados         BIT NOT NULL DEFAULT 0
);

-------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[habitaciones] -- 12
(
    id_habitacion            INT IDENTITY (1, 1) PRIMARY KEY,
    id_hotel                 INT NOT NULL,
    numero_habitacion        NUMERIC(18,0) NOT NULL,
    piso_habitacion          NUMERIC(18,0),
    ubicacion_habitacion     NVARCHAR(50),
    id_tipo_habitacion       INT NOT NULL,
    descripcion_habitacion   NVARCHAR(255)

    UNIQUE(id_hotel, numero_habitacion)
);


-------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[usuarios] -- 13
(
    id_usuario                    INT IDENTITY (1, 1) PRIMARY KEY,
    nombre_usuario                NVARCHAR(255) NOT NULL,
    apellido_usuario              NVARCHAR(255) NOT NULL,
    id_tipo_documento             INT NOT NULL,
    numero_documento_usuario      NUMERIC(18,0) NOT NULL,
    correo_usuario                NVARCHAR(255) NOT NULL,
    telefono_usuario              NVARCHAR(100) NOT NULL,
    direccion_usuario             NVARCHAR(255) NOT NULL,
    fecha_nacimiento_usuario      DATETIME NOT NULL,
    estado_usuario                BIT NOT NULL DEFAULT 1
    
    UNIQUE(id_tipo_documento, numero_documento_usuario)
);


-------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[reservasXhabitaciones] -- 14
(
    id_reserva        INT NOT NULL,
    id_habitacion     INT NOT NULL
    
    PRIMARY KEY(id_reserva, id_habitacion)
);


-------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[tipos_habitacion] -- 15
(
    id_tipo_habitacion                    INT IDENTITY (1001, 1) PRIMARY KEY,
    descripcion_tipo_habitacion           NVARCHAR(255),
    porcentual_tipo_habitacion            NUMERIC(18,2) NOT NULL,
    cantidad_huespedes_tipo_habitacion    NUMERIC(18,0) NOT NULL
);


-------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[usuariosXroles] -- 16
(
    id_rol        INT NOT NULL,
    id_usuario    INT NOT NULL
    
    PRIMARY KEY(id_rol, id_usuario)
);


-------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[cancelaciones_reserva] -- 17
(
    id_cancelacion_reserva        INT IDENTITY (1, 1) PRIMARY KEY,
    id_reserva                    INT NOT NULL,
    motivo_cancelacion_reserva    NVARCHAR(2500),
    fecha_cancelacion_reserva     DATETIME NOT NULL,
    id_usuario                    INT NOT NULL
);


-------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[reservas] -- 18
(
    id_reserva                    INT IDENTITY (10001, 1) PRIMARY KEY,
    fecha_realizacion_reserva     DATETIME NOT NULL,
    fecha_inicio_reserva          DATETIME NOT NULL,
    fecha_fin_reserva             DATETIME NOT NULL,
    id_cliente                    INT NOT NULL,
    id_regimen                    INT NOT NULL,
    id_estado_reserva             INT NOT NULL DEFAULT 1
);


-------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[estados_reserva] -- 19
(
    id_estado_reserva                INT IDENTITY (1, 1) PRIMARY KEY,
    descripcion_estados_reserva      NVARCHAR(255) NOT NULL
);


-------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[usuariosXhoteles] -- 20
(
    id_usuario    INT NOT NULL,
    id_hotel      INT NOT NULL
    
    PRIMARY KEY (id_usuario, id_hotel)
);


-------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[paises] -- 21
(
    id_pais        INT IDENTITY (1, 1) PRIMARY KEY,
    nombre_pais    NVARCHAR(255) NOT NULL
);

-------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[roles] -- 22
(
    id_rol        INT IDENTITY (1, 1) PRIMARY KEY,
    nombre_rol    NVARCHAR(255) NOT NULL,
    estado_rol    BIT NOT NULL DEFAULT 1
);


-------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[regimenes] -- 23
(
    id_regimen            INT IDENTITY (1, 1) PRIMARY KEY,
    descripcion_regimen   NVARCHAR(255) NOT NULL,
    precio_base_regimen   NUMERIC(18,2) NOT NULL,
    estado_regimen        BIT NOT NULL DEFAULT 1
);


-------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[hotelesXregimenes] -- 24
(
    id_hotel        INT NOT NULL,
    id_regimen      INT NOT NULL
    
    PRIMARY KEY (id_hotel, id_regimen)
);


-------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[hoteles] -- 25
(
    id_hotel                        INT IDENTITY (1, 1) PRIMARY KEY,
    nombre_hotel                    NVARCHAR(255) NOT NULL DEFAULT 'Hotel sin nombre',
    correo_hotel                    NVARCHAR(255) NOT NULL DEFAULT 'hotel@emdlm.com',
    telefono_hotel                  NVARCHAR(100) NOT NULL DEFAULT '0800-000-0000',
    ciudad_hotel                    NVARCHAR(255) NOT NULL,
    domicilio_calle_hotel           NVARCHAR(255) NOT NULL,
    domicilio_numero_hotel          NUMERIC(18,0) NOT NULL,
    cantidad_estrellas_hotel        NUMERIC(18,0) NOT NULL,
    id_pais                         INT NOT NULL DEFAULT 10,
    fecha_creacion_hotel            DATETIME NOT NULL DEFAULT convert(datetime, '20010101', 112),
    recarga_por_estrellas_hotel     NUMERIC(18,0) NOT NULL
);


-------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] -- 26
(
    id_rol                INT NOT NULL,
    id_funcionalidad      INT NOT NULL
    
    PRIMARY KEY (id_rol, id_funcionalidad)
);

-------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[funcionalidades] -- 27
(
    id_funcionalidad            INT IDENTITY (1, 1) PRIMARY KEY,
    descripcion_funcionalidad   NVARCHAR(255) NOT NULL
);


-------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[cierres_temporales_hotel] -- 28
(
    id_cierre_temporal_hotel            INT IDENTITY (1, 1) PRIMARY KEY,
    fecha_inicio_cierre_temporal_hotel  DATETIME NOT NULL,
    fecha_fin_cierre_temporal_hotel     DATETIME NOT NULL,
    id_hotel                            INT NOT NULL,
    motivo_cierre_temporal_hotel        NVARCHAR(2500) NOT NULL
);

-------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[generacion_modificacion_reservas] -- 29
(
    id_generacion_modificacion_reserva      INT IDENTITY(1, 1) PRIMARY KEY,
    id_reserva                              INT NOT NULL,
    id_usuario                              INT NOT NULL,
    tipo_generacion_modificacion_reserva    NCHAR(1) NOT NULL,
    fecha_generacion_modificacion_reserva   DATETIME NOT NULL
);

-------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[migracion_errores]
(
    id_reserva numeric(18, 0) NULL,
    id_estadia int NULL,
    id_cliente int NULL,
    numero_documento_cliente numeric(18, 0) NULL,
    apellido_cliente nvarchar(255) NULL,
    nombre_cliente nvarchar(255) NULL,
    fecha_nacimiento_cliente datetime NULL,
    correo_cliente nvarchar(255) NULL,
    domicilio_calle_cliente nvarchar(255) NULL,
    domicilio_numero_cliente numeric(18, 0) NULL,
    domicilio_piso_cliente numeric(18, 0) NULL,
    domicilio_departamento_cliente nvarchar(50) NULL,
    nacionalidad_cliente nvarchar(255) NULL
);

GO

INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Afghanistan');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Albania');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Algeria');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('American Samoa');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Andorra');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Angola');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Anguilla');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Antarctica');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Antigua and Barbuda');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Argentina');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Armenia');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Aruba');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Australia');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Austria');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Azerbaijan');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Bahamas');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Bahrain');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Bangladesh');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Barbados');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Belarus');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Belgium');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Belize');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Benin');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Bermuda');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Bhutan');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Bolivia');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Bosnia and Herzegovina');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Botswana');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Bouvet Island');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Brazil');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('British Indian Ocean Territory');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Brunei Darussalam');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Bulgaria');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Burkina Faso');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Burundi');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Cambodia');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Cameroon');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Canada');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Cape Verde');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Cayman Islands');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Central African Republic');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Chad');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Chile');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('China');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Christmas Island');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Cocos (Keeling) Islands');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Colombia');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Comoros');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Congo');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Cook Islands');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Costa Rica');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Croatia (Hrvatska)');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Cuba');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Cyprus');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Czech Republic');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Denmark');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Djibouti');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Dominica');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Dominican Republic');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('East Timor');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Ecuador');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Egypt');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('El Salvador');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Equatorial Guinea');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Eritrea');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Estonia');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Ethiopia');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Falkland Islands (Malvinas)');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Faroe Islands');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Fiji');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Finland');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('France');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('France, Metropolitan');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('French Guiana');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('French Polynesia');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('French Southern Territories');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Gabon');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Gambia');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Georgia');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Germany');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Ghana');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Gibraltar');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Guernsey');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Greece');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Greenland');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Grenada');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Guadeloupe');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Guam');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Guatemala');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Guinea');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Guinea-Bissau');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Guyana');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Haiti');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Heard and Mc Donald Islands');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Honduras');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Hong Kong');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Hungary');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Iceland');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('India');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Isle of Man');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Indonesia');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Iran (Islamic Republic of)');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Iraq');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Ireland');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Israel');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Italy');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Ivory Coast');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Jersey');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Jamaica');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Japan');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Jordan');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Kazakhstan');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Kenya');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Kiribati');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Korea, Democratic People''s Republic of');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Korea, Republic of');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Kosovo');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Kuwait');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Kyrgyzstan');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Lao People''s Democratic Republic');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Latvia');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Lebanon');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Lesotho');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Liberia');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Libyan Arab Jamahiriya');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Liechtenstein');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Lithuania');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Luxembourg');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Macau');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Macedonia');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Madagascar');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Malawi');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Malaysia');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Maldives');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Mali');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Malta');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Marshall Islands');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Martinique');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Mauritania');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Mauritius');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Mayotte');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Mexico');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Micronesia, Federated States of');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Moldova, Republic of');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Monaco');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Mongolia');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Montenegro');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Montserrat');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Morocco');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Mozambique');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Myanmar');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Namibia');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Nauru');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Nepal');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Netherlands');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Netherlands Antilles');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('New Caledonia');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('New Zealand');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Nicaragua');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Niger');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Nigeria');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Niue');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Norfolk Island');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Northern Mariana Islands');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Norway');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Oman');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Pakistan');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Palau');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Palestine');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Panama');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Papua New Guinea');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Paraguay');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Peru');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Philippines');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Pitcairn');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Poland');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Portugal');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Puerto Rico');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Qatar');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Reunion');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Romania');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Russian Federation');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Rwanda');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Saint Kitts and Nevis');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Saint Lucia');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Saint Vincent and the Grenadines');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Samoa');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('San Marino');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Sao Tome and Principe');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Saudi Arabia');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Senegal');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Serbia');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Seychelles');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Sierra Leone');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Singapore');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Slovakia');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Slovenia');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Solomon Islands');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Somalia');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('South Africa');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('South Georgia South Sandwich Islands');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Spain');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Sri Lanka');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('St. Helena');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('St. Pierre and Miquelon');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Sudan');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Suriname');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Svalbard and Jan Mayen Islands');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Swaziland');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Sweden');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Switzerland');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Syrian Arab Republic');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Taiwan');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Tajikistan');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Tanzania, United Republic of');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Thailand');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Togo');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Tokelau');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Tonga');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Trinidad and Tobago');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Tunisia');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Turkey');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Turkmenistan');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Turks and Caicos Islands');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Tuvalu');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Uganda');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Ukraine');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('United Arab Emirates');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('United Kingdom');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('United States');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('United States minor outlying islands');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Uruguay');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Uzbekistan');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Vanuatu');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Vatican City State');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Venezuela');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Vietnam');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Virgin Islands (British)');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Virgin Islands (U.S.)');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Wallis and Futuna Islands');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Western Sahara');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Yemen');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Zaire');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Zambia');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[paises] VALUES ('Zimbabwe');

GO

INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[estados_reserva] VALUES ('Reserva correcta');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[estados_reserva] VALUES ('Reserva modificada');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[estados_reserva] VALUES ('Reserva cancelada por recepción');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[estados_reserva] VALUES ('Reserva cancelada por cliente');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[estados_reserva] VALUES ('Reserva cancelada por no-show');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[estados_reserva] VALUES ('Reserva con ingreso (efectivizada)');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[estados_reserva] VALUES ('Reserva desconocida');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[estados_reserva] VALUES ('Reserva cancelada por motivo desconocido');

GO

INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[formas_de_pago] VALUES ('Efectivo');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[formas_de_pago] VALUES ('Tarjeta de crédito');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[formas_de_pago] VALUES ('Tarjeta de débito');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[formas_de_pago] VALUES ('Transferencia bancaria');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[formas_de_pago] VALUES ('Cheque al portador');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[formas_de_pago] VALUES ('Cheque a la orden');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[formas_de_pago] VALUES ('Cheque cancelatorio');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[formas_de_pago] VALUES ('PayPal');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[formas_de_pago] VALUES ('Bitcoin');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[formas_de_pago] VALUES ('MercadoPago');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[formas_de_pago] VALUES ('Rapipago');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[formas_de_pago] VALUES ('Cupón de premio');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[formas_de_pago] VALUES ('Otro/desconocido');

GO

INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[tipos_documento] VALUES ('Documento nacional de identidad', 'DNI');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[tipos_documento] VALUES ('Libreta de enrolamiento', 'LE');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[tipos_documento] VALUES ('Libreta cívica', 'LC');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[tipos_documento] VALUES ('Cédula de identidad del Mercosur', 'CM');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[tipos_documento] VALUES ('Pasaporte', 'PP');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[tipos_documento] VALUES ('Desconocido', 'DD');

GO

INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[usuarios] VALUES ('dummy','dummy', 6, 0, 'dummy@dummy.com', '', '', convert(datetime, '20010101', 112), 1);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[usuarios] VALUES ('Administrador','General', 6, 1, 'admin@admin.com', '', '', convert(datetime, '20010101', 112), 1);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[cuentas] VALUES (2, 'admin', 'e6b87050bfcb8143fcb8db0170a4dc9ed00d904ddd3e2a4ad1b1e8dc0fdc9be7', 0);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[clientes] (nombre_cliente, apellido_cliente, id_tipo_documento, numero_documento_cliente, correo_cliente)
VALUES ('Cliente', 'Dummy', 6, -1, 'clienteDummy@emdlm.com');

GO

CREATE TRIGGER [EL_MONSTRUO_DEL_LAGO_MASER].[add_users_for_new_hotel] ON [EL_MONSTRUO_DEL_LAGO_MASER].[hoteles]
AFTER INSERT AS
BEGIN
    INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[usuariosXhoteles]
    SELECT 1, id_hotel
    FROM inserted

    INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[usuariosXhoteles]
    SELECT 2, id_hotel
    FROM inserted
END;

GO
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[funcionalidades] VALUES ('Dar de alta reserva');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[funcionalidades] VALUES ('Modificar reserva');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[funcionalidades] VALUES ('Cancelar reserva');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[funcionalidades] VALUES ('Agregar rol');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[funcionalidades] VALUES ('Editar rol');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[funcionalidades] VALUES ('Borrar rol');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[funcionalidades] VALUES ('Dar de alta usuario');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[funcionalidades] VALUES ('Modificar usuario');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[funcionalidades] VALUES ('Borrar usuario');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[funcionalidades] VALUES ('Dar de alta cliente');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[funcionalidades] VALUES ('Modificar cliente');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[funcionalidades] VALUES ('Inhabilitar cliente');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[funcionalidades] VALUES ('Dar de alta hotel');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[funcionalidades] VALUES ('Modificar hotel');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[funcionalidades] VALUES ('Cerrar temporalmente hotel');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[funcionalidades] VALUES ('Dar de alta habitación');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[funcionalidades] VALUES ('Modificar habitación');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[funcionalidades] VALUES ('Borrar habitación');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[funcionalidades] VALUES ('Dar de alta regimen');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[funcionalidades] VALUES ('Modificar regimen');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[funcionalidades] VALUES ('Eliminar regimen');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[funcionalidades] VALUES ('Registrar inicio y fin de estadía');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[funcionalidades] VALUES ('Registrar consumibles');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[funcionalidades] VALUES ('Facturar');
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[funcionalidades] VALUES ('Obtener listado');

GO

INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[roles] VALUES ('Guest', 1);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[roles] VALUES ('Administrador General', 1);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[roles] VALUES ('Recepcionista', 1);

GO

INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (1, 1);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (1, 2);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (1, 3);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (2, 1);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (2, 2);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (2, 3);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (2, 4);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (2, 5);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (2, 6);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (2, 7);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (2, 8);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (2, 9);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (2, 10);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (2, 11);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (2, 12);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (2, 13);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (2, 14);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (2, 15);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (2, 16);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (2, 17);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (2, 18);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (2, 19);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (2, 20);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (2, 21);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (2, 22);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (2, 23);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (2, 24);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (2, 25);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (3, 1);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (3, 2);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (3, 3);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (3, 10);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (3, 11);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (3, 12);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (3, 22);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (3, 23);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] VALUES (3, 24);

GO

INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[usuariosXroles] VALUES (2, 2);
INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[usuariosXroles] VALUES (1, 1);

GO
-- Procedure de seguridad q explota si no tenes permisos de ejecutar eso
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO]
	(@id_rol INT, @id_funcionalidad INT)
AS
BEGIN
	IF (NOT EXISTS(SELECT id_rol, id_funcionalidad
				   FROM [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades]
				   WHERE id_rol = @id_rol AND id_funcionalidad = @id_funcionalidad))
	BEGIN
		RAISERROR('Su rol activo no tiene los permisos correspondientes', 20, 1) WITH LOG
	END
END

GO


-- Obtiene el listado de funcionalidades
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_FUNCIONALIDADES]
AS
BEGIN
	SELECT id_funcionalidad, descripcion_funcionalidad
	FROM [EL_MONSTRUO_DEL_LAGO_MASER].[funcionalidades]
END

GO

-- Obtiene el ID de un usuario dummy (para los visitantes)
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_USUARIO_DUMMY]
AS
BEGIN
    SELECT 1 id_usuario
END

GO

-- Obtiene el ID del rol guest (que es 1 por nuestra lógicaa)
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_ROL_GUEST]
AS
BEGIN
    SELECT 1 id_rol
END

GO

-- Se ejecuta para crear un rol nuevo
CREATE TYPE [EL_MONSTRUO_DEL_LAGO_MASER].[listaDeFuncionalidades] AS TABLE
	(id_funcionalidad INT)

GO

CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[INSERTAR_NUEVO_ROL](@id_rol_user INT, @nombre_rol NVARCHAR(255), @funcionalidades EL_MONSTRUO_DEL_LAGO_MASER.listaDeFuncionalidades READONLY)
AS
BEGIN

    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO] @id_rol_user, 4

	BEGIN TRY
		DECLARE @id_funcionalidad       INT
		DECLARE @id_rol                 INT
		DECLARE cursor_funcionalidades CURSOR FOR
				SELECT id_funcionalidad
				FROM @funcionalidades

		BEGIN TRANSACTION

		INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[roles]
			(nombre_rol)
		VALUES(@nombre_rol)

		-- Seteamos el ID del ROL CREADO
		SET @id_rol = SCOPE_IDENTITY();

		-- Vamos insertando en la muchos a muchos para agregarle funcionalidades
		OPEN cursor_funcionalidades
		FETCH cursor_funcionalidades INTO @id_funcionalidad
		WHILE(@@FETCH_STATUS = 0)
		BEGIN
			INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades]
				(id_rol,id_funcionalidad)
			VALUES (@id_rol,@id_funcionalidad)
		FETCH cursor_funcionalidades INTO @id_funcionalidad
		END

		COMMIT TRANSACTION

		CLOSE cursor_funcionalidades
		DEALLOCATE cursor_funcionalidades
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION

		IF CURSOR_STATUS('global', 'cursor_funcionalidades') = 1 BEGIN
			CLOSE cursor_funcionalidades
		END
		DEALLOCATE cursor_funcionalidades;

		THROW
	END CATCH
END

GO

-- Se ejecuta para traer los roles
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_ROLES_FILTRADOS]
(@nombre NVARCHAR(255), @funcionalidad INT, @soloActivos BIT)
AS
BEGIN
        SELECT DISTINCT r.id_rol, nombre_rol, estado_rol
        FROM [EL_MONSTRUO_DEL_LAGO_MASER].[roles] r
        JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades] rxf
        ON r.id_rol = rxf.id_rol
        WHERE LOWER(nombre_rol) LIKE '%' + LOWER(@nombre) + '%'
        AND (@funcionalidad = -1 OR id_funcionalidad = @funcionalidad)
        -- Azucar sintáctico para no tener que crear dos selects distintos
        -- Uno con filtro y otro sin filtro
        AND (@soloActivos = 0 OR estado_rol = 1)
        -- Lo mismo para roles, para que traiga solo los activos, o todos
END

GO

-- Obtiene las funcionalidades de un rol en particular
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_FUNCIONALIDADES_DE_ROL]
        (@id_rol INT)
AS
BEGIN
        SELECT id_funcionalidad
        FROM [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades]
        WHERE id_rol = @id_rol
END

GO

-- Deshabilita un rol en particular
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[DESHABILITAR_ROL]
        (@id_rol_user INT, @id_rol INT)
AS
BEGIN
	
	EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO] @id_rol_user, 6
	
    UPDATE [EL_MONSTRUO_DEL_LAGO_MASER].[roles]
    SET estado_rol = 0
    WHERE id_rol = @id_rol
END

GO

-- Modifica un rol por su ID
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[MODIFICAR_ROL]
        (@id_rol_user INT, @id_rol INT, @nombre_rol NVARCHAR(255), @funcionalidades EL_MONSTRUO_DEL_LAGO_MASER.listaDeFuncionalidades READONLY, @estado BIT)
AS
BEGIN

    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO] @id_rol_user, 5

    DECLARE @id_funcionalidad    INT

    DECLARE cursor_funcionalidades CURSOR FOR
        SELECT id_funcionalidad
        FROM @funcionalidades
	
	BEGIN TRY
		BEGIN TRANSACTION
		--Updateamos el rol
		UPDATE [EL_MONSTRUO_DEL_LAGO_MASER].[roles]
			SET nombre_rol = @nombre_rol, estado_rol = @estado
			WHERE id_rol = @id_rol

		--Borramos todas las funcoinalidades de ese rol
		DELETE FROM [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades]
		WHERE id_rol = @id_rol

		-- Insertamos todas las funcoinalidades que nos mandan en la lista
		OPEN cursor_funcionalidades
		FETCH cursor_funcionalidades INTO @id_funcionalidad
			WHILE(@@FETCH_STATUS = 0)
			BEGIN
				INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades]
					(id_rol,id_funcionalidad)
				VALUES (@id_rol, @id_funcionalidad)
							FETCH cursor_funcionalidades INTO @id_funcionalidad
			END

		COMMIT TRANSACTION
		CLOSE cursor_funcionalidades
		DEALLOCATE cursor_funcionalidades
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION

		IF CURSOR_STATUS('global', 'cursor_funcionalidades') = 1 BEGIN
			CLOSE cursor_funcionalidades
		END
		DEALLOCATE cursor_funcionalidades;

		THROW
	END CATCH
END

GO

-- Obtiene los hoteles
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_HOTELES]
AS
BEGIN
    SELECT id_hotel, nombre_hotel, correo_hotel, telefono_hotel, ciudad_hotel, domicilio_calle_hotel, domicilio_numero_hotel,
		   cantidad_estrellas_hotel, id_pais, fecha_creacion_hotel, recarga_por_estrellas_hotel
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[hoteles] 
END

GO

-- Obtiene los roles
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_ROLES]
AS
BEGIN
    SELECT id_rol, nombre_rol, estado_rol
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[roles] 
END

GO

-- Obtiene los hoteles pero de un cierto usuario (solo el ID)
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_HOTELES_DE_UN_USUARIO] (@id_usuario INT)
AS
BEGIN
    SELECT id_hotel
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[usuariosXhoteles]
    WHERE id_usuario = @id_usuario
END

GO

-- Obtiene los roles pero solo de un usuario (y solo el ID de estos)
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_ROLES_DE_UN_USUARIO] (@id_usuario INT)
AS
BEGIN
    SELECT id_rol
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[usuariosXroles]
    WHERE id_usuario = @id_usuario
END

GO

-- Devuelve un pais en base a su id
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_PAIS] (@id_pais INT)
AS
BEGIN
    SELECT nombre_pais
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[paises]
    WHERE id_pais = @id_pais
END

GO

-- Trae todos los tipos de documento
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_TIPOS_DOCUMENTO]
AS
BEGIN
    SELECT id_tipo_documento, nombre_tipo_documento, sigla_tipo_documento
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[tipos_documento]
END

GO


CREATE TYPE [EL_MONSTRUO_DEL_LAGO_MASER].[listaDeRoles] AS TABLE
(id_rol INT)

GO

CREATE TYPE [EL_MONSTRUO_DEL_LAGO_MASER].[listaDeHoteles] AS TABLE
(id_hotel INT)

GO

-- Se ejecuta para crear un usuario nuevo
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[INSERTAR_USUARIO](@id_rol_user INT, @usuario_cuenta NVARCHAR(255), @contraseña_cuenta CHAR(64), @roles EL_MONSTRUO_DEL_LAGO_MASER.listaDeRoles READONLY, 
@hoteles EL_MONSTRUO_DEL_LAGO_MASER.listaDeHoteles READONLY, @nombre_usuario NVARCHAR(255), @apellido_usuario NVARCHAR(255), @id_tipo_documento INT, @numero_documento_usuario NUMERIC(18,0), @correo_usuario NVARCHAR(255), @telefono_usuario NVARCHAR(100), @direccion_usuario NVARCHAR(255), @fecha_nacimiento_usuario DATETIME)
AS
BEGIN
    DECLARE @id_usuario             INT
    DECLARE @id_rol                 INT
    DECLARE @id_hotel				INT
    
    DECLARE cursor_roles CURSOR FOR
		SELECT id_rol
		FROM @roles

    DECLARE cursor_hoteles CURSOR FOR
        SELECT id_hotel
        FROM @hoteles

    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO] @id_rol_user, 7

	BEGIN TRY
		BEGIN TRANSACTION
        INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[usuarios]
            (nombre_usuario, apellido_usuario, id_tipo_documento, numero_documento_usuario, correo_usuario, telefono_usuario, direccion_usuario,fecha_nacimiento_usuario)
		VALUES(@nombre_usuario, @apellido_usuario, @id_tipo_documento, @numero_documento_usuario, @correo_usuario, @telefono_usuario, @direccion_usuario, @fecha_nacimiento_usuario)

        -- Seteamos el ID del USUARIO CREADO
                SET @id_usuario = SCOPE_IDENTITY();

        INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[cuentas]
                        (id_usuario, usuario_cuenta, contraseña_cuenta)
        VALUES(@id_usuario, LOWER(@usuario_cuenta), LOWER(@contraseña_cuenta))


		-- Vamos insertando los roles del usuario
		OPEN cursor_roles
		FETCH cursor_roles INTO @id_rol
		WHILE(@@FETCH_STATUS = 0) BEGIN
			INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[usuariosXroles]
				(id_usuario, id_rol)
			VALUES (@id_usuario, @id_rol)
			FETCH cursor_roles INTO @id_rol
		END
		CLOSE cursor_roles
		DEALLOCATE cursor_roles

		-- Vamos insertando los hoteles del usuario
		OPEN cursor_hoteles
		FETCH cursor_hoteles INTO @id_hotel
		WHILE(@@FETCH_STATUS = 0) BEGIN
			INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[usuariosXhoteles]
				(id_usuario, id_hotel)
			VALUES (@id_usuario, @id_hotel)
		FETCH cursor_hoteles INTO @id_hotel
		END

		COMMIT TRANSACTION
		CLOSE cursor_hoteles
		DEALLOCATE cursor_hoteles
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION

		IF CURSOR_STATUS('global', 'cursor_roles') = 1 BEGIN
			CLOSE cursor_roles
		END
		DEALLOCATE cursor_roles;

		IF CURSOR_STATUS('global', 'cursor_hoteles') = 1 BEGIN
			CLOSE cursor_hoteles
		END
		DEALLOCATE cursor_hoteles;

		THROW
	END CATCH
END

GO

-- Obtiene los usuarios filtrados
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_USUARIOS_FILTRADOS]
	(@usuario_cuenta NVARCHAR(255), @id_rol INT, @nombre_usuario NVARCHAR(255), @apellido_usuario NVARCHAR(255),
	@id_tipo_documento INT, @numero_documento_usuario NUMERIC(18,0), @correo_usuario NVARCHAR(255), @id_hotel INT, @soloActivos BIT)
AS
BEGIN
        SELECT DISTINCT u.id_usuario, usuario_cuenta, nombre_usuario, 
			apellido_usuario, id_tipo_documento, numero_documento_usuario, correo_usuario, telefono_usuario, 
			direccion_usuario, fecha_nacimiento_usuario, estado_usuario 
        FROM [EL_MONSTRUO_DEL_LAGO_MASER].[usuarios] u
		JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[cuentas] c
		ON u.id_usuario = c.id_usuario
        JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[usuariosXhoteles] uxh
        ON u.id_usuario = uxh.id_usuario
		JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[usuariosXroles] uxr
		ON u.id_usuario = uxr.id_usuario
        WHERE LOWER(usuario_cuenta) LIKE '%' + LOWER(@usuario_cuenta) + '%'
        AND (@id_rol = -1 OR id_rol = @id_rol)
		AND LOWER(nombre_usuario) LIKE '%' + LOWER(@nombre_usuario) + '%'
		AND LOWER(apellido_usuario) LIKE '%' + LOWER(@apellido_usuario) + '%'
		AND (@id_tipo_documento = -1 OR id_tipo_documento = @id_tipo_documento)
		AND (@numero_documento_usuario = 0 OR CAST(numero_documento_usuario AS VARCHAR) LIKE '%' + CAST(@numero_documento_usuario AS VARCHAR) + '%')
		AND LOWER(correo_usuario) LIKE '%' + LOWER(@correo_usuario) + '%'
		AND (@id_hotel = -1 OR id_hotel = @id_hotel)
        AND (@soloActivos = 0 OR estado_usuario = 1)
END

GO

-- Deshabilita un usuario en particular
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[DESHABILITAR_USUARIO]
        (@id_rol_user INT, @id_usuario INT)
AS
BEGIN

    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO] @id_rol_user, 9

    UPDATE [EL_MONSTRUO_DEL_LAGO_MASER].[usuarios]
    SET estado_usuario = 0
    WHERE id_usuario = @id_usuario
END

GO

-- Modifica un usuario en particular
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[MODIFICAR_USUARIO](@id_rol_user INT, @id_usuario INT, @usuario_cuenta NVARCHAR(255), @contraseña_cuenta CHAR(64), @roles EL_MONSTRUO_DEL_LAGO_MASER.listaDeRoles READONLY,
	@hoteles EL_MONSTRUO_DEL_LAGO_MASER.listaDeHoteles READONLY, @nombre_usuario NVARCHAR(255), @apellido_usuario NVARCHAR(255), @id_tipo_documento INT, @numero_documento_usuario NUMERIC(18,0), @correo_usuario NVARCHAR(255), 
	@telefono_usuario NVARCHAR(100), @direccion_usuario NVARCHAR(255), @fecha_nacimiento_usuario DATETIME, @estado BIT)
AS
BEGIN
    DECLARE @id_rol                 INT
    DECLARE @id_hotel               INT

    DECLARE cursor_roles CURSOR FOR
                SELECT id_rol
                FROM @roles

    DECLARE cursor_hoteles CURSOR FOR
        SELECT id_hotel
        FROM @hoteles

    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO] @id_rol_user, 8

        BEGIN TRY
				BEGIN TRANSACTION
				UPDATE [EL_MONSTRUO_DEL_LAGO_MASER].[usuarios]
				SET nombre_usuario = @nombre_usuario,
					apellido_usuario = @apellido_usuario,
					id_tipo_documento = @id_tipo_documento,
					numero_documento_usuario = @numero_documento_usuario,
					correo_usuario = @correo_usuario,
					telefono_usuario = @telefono_usuario,
					direccion_usuario = @direccion_usuario,
					fecha_nacimiento_usuario = @fecha_nacimiento_usuario,
					estado_usuario = @estado
				WHERE id_usuario = @id_usuario

				UPDATE [EL_MONSTRUO_DEL_LAGO_MASER].[cuentas]
				SET usuario_cuenta = LOWER(@usuario_cuenta),
					contraseña_cuenta = CASE @contraseña_cuenta
					WHEN 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' THEN contraseña_cuenta
					ELSE LOWER(@contraseña_cuenta)
					END
				WHERE id_usuario = @id_usuario

				-- Limpiamos relaciones muchos a muchos
				DELETE FROM [EL_MONSTRUO_DEL_LAGO_MASER].[usuariosXhoteles]
				WHERE id_usuario = @id_usuario

				DELETE FROM [EL_MONSTRUO_DEL_LAGO_MASER].[usuariosXroles]
				WHERE id_usuario = @id_usuario

                -- Vamos insertando los roles del usuario
                OPEN cursor_roles
                FETCH cursor_roles INTO @id_rol
                WHILE(@@FETCH_STATUS = 0) BEGIN
                        INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[usuariosXroles]
                                (id_usuario, id_rol)
                        VALUES (@id_usuario, @id_rol)
                        FETCH cursor_roles INTO @id_rol
                END
                CLOSE cursor_roles
                DEALLOCATE cursor_roles
                -- Vamos insertando los hoteles del usuario
                OPEN cursor_hoteles
                FETCH cursor_hoteles INTO @id_hotel
                WHILE(@@FETCH_STATUS = 0) BEGIN
                        INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[usuariosXhoteles]
                                (id_usuario, id_hotel)
                        VALUES (@id_usuario, @id_hotel)
                FETCH cursor_hoteles INTO @id_hotel
                END

                COMMIT TRANSACTION
                CLOSE cursor_hoteles
                DEALLOCATE cursor_hoteles
        END TRY
        BEGIN CATCH
                ROLLBACK TRANSACTION

                IF CURSOR_STATUS('global', 'cursor_roles') = 1 BEGIN
                        CLOSE cursor_roles
                END
                DEALLOCATE cursor_roles;

                IF CURSOR_STATUS('global', 'cursor_hoteles') = 1 BEGIN
                        CLOSE cursor_hoteles
                END
                DEALLOCATE cursor_hoteles;

                THROW
        END CATCH
END


GO

-- Usado para hacer el login
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[LOGIN_USUARIO]
	(@usuario_cuenta NVARCHAR(255), @contraseña_cuenta CHAR(64))
AS
BEGIN
	DECLARE @id_usuario		INT
	DECLARE @pass_real		CHAR(64)
	DECLARE @intentos		NUMERIC(1,0)
	DECLARE @estado			BIT

	-- Valida si existe el usuario con ese numero
	SELECT @id_usuario = c.id_usuario, @pass_real = contraseña_cuenta, 
		   @intentos = intentos_acceso_cuenta, @estado = estado_usuario
	FROM [EL_MONSTRUO_DEL_LAGO_MASER].[cuentas] c
	JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[usuarios] u
	ON c.id_usuario = u.id_usuario
	WHERE usuario_cuenta = LOWER(@usuario_cuenta) -- es unique key, devuelve unica siempre

	IF (@id_usuario IS NULL) BEGIN
		SELECT -3 id_usuario -- No hay usuario (devuelvo un user con -3)
	END
	ELSE IF (LOWER(@contraseña_cuenta) != LOWER(@pass_real)) BEGIN
		SELECT -1 id_usuario -- Credenciales inválidas (devuelvo un user con -1)

		IF (@intentos = 2) BEGIN -- Este fue el tercer intento (el 2 era el guardado previamente)
			UPDATE [EL_MONSTRUO_DEL_LAGO_MASER].[usuarios]
			SET estado_usuario = 0
			WHERE id_usuario = @id_usuario

			UPDATE [EL_MONSTRUO_DEL_LAGO_MASER].[cuentas]
			SET intentos_acceso_cuenta = 0
			WHERE id_usuario = @id_usuario

			SET @estado = 0
		END

		-- Aumentamos la cantidad del contador (si sigue aactivo)
		IF (@estado = 1) BEGIN
			UPDATE [EL_MONSTRUO_DEL_LAGO_MASER].[cuentas]
			SET intentos_acceso_cuenta = @intentos + 1
			WHERE id_usuario = @id_usuario
		END
	END
	ELSE IF (@estado = 0) BEGIN
		SELECT -2 id_usuario -- Usuario deshabilitado (devuelvo un user con -2)
	END
	ELSE BEGIN
		SELECT id_usuario, nombre_usuario, apellido_usuario, id_tipo_documento, numero_documento_usuario,
			   correo_usuario, telefono_usuario, direccion_usuario, fecha_nacimiento_usuario, estado_usuario
		FROM [EL_MONSTRUO_DEL_LAGO_MASER].[usuarios]
		WHERE id_usuario = @id_usuario

		-- Reinicio el contador
		UPDATE [EL_MONSTRUO_DEL_LAGO_MASER].[cuentas]
		SET intentos_acceso_cuenta = 0
		WHERE id_usuario = @id_usuario
	END
END

GO

-- Obtiene la lista de paises
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_PAISES]
AS
BEGIN
    SELECT id_pais, nombre_pais
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[paises]
END

GO

-- Trae los clientes con los filtros posibles.
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_CLIENTES_FILTRADOS](@nombre nvarchar(255), @apellido nvarchar(255),@id_documento int,
    @numero_documento numeric(18,0), @correo nvarchar(255), @soloActivos BIT)
AS
BEGIN

    SELECT TOP 100 id_cliente, nombre_cliente, apellido_cliente, id_tipo_documento, numero_documento_cliente, correo_cliente, telefono_cliente, domicilio_calle_cliente,
        domicilio_numero_cliente, domicilio_piso_cliente, domicilio_departamento_cliente, ciudad_cliente, id_pais, nacionalidad_cliente, fecha_nacimiento_cliente, estado_cliente    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[clientes]
    WHERE LOWER(nombre_cliente) LIKE '%' + LOWER(@nombre) + '%'
    AND LOWER(apellido_cliente) LIKE '%' + LOWER(@apellido) + '%'
    AND LOWER(correo_cliente) LIKE '%' + LOWER(@correo) + '%'
    AND (@id_documento = -1 OR id_tipo_documento = @id_documento)
    AND (@numero_documento = 0 OR CAST (numero_documento_cliente AS VARCHAR) LIKE '%' + CAST (@numero_documento AS VARCHAR) + '%')
    AND (@soloActivos = 0 OR estado_cliente = 1)
    AND id_cliente != 0
END

GO

-- Crea un cliente (sin validar permisos)
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[INSERTAR_NUEVO_CLIENTE_SIN_VALIDACION] (@nombre nvarchar(255), @apellido nvarchar(255), @id_documento int,
    @numero_documento numeric(18,0), @correo nvarchar(255),@telefono nvarchar(100),@domicilio_calle nvarchar(255),@domicilio_numero numeric(18,0),
    @domicilio_piso numeric(18,0), @domicilio_departamento nvarchar(50), @ciudad nvarchar(255), @pais int, @nacionalidad nvarchar(255), @fecha_nacimiento datetime)
AS
BEGIN
    IF (@domicilio_piso = 0) BEGIN
        SET @domicilio_piso = NULL
    END

    INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[clientes]
        (nombre_cliente, apellido_cliente, id_tipo_documento, numero_documento_cliente, correo_cliente, telefono_cliente, domicilio_calle_cliente, domicilio_numero_cliente,
        domicilio_piso_cliente, domicilio_departamento_cliente, ciudad_cliente, id_pais, nacionalidad_cliente, fecha_nacimiento_cliente)
    VALUES(@nombre, @apellido, @id_documento, @numero_documento, @correo, @telefono, @domicilio_calle, @domicilio_numero, @domicilio_piso, @domicilio_departamento,
        @ciudad, @pais, @nacionalidad, @fecha_nacimiento)

    SELECT SCOPE_IDENTITY() id_cliente
END

GO

-- Crea un cliente (con validación)
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[INSERTAR_NUEVO_CLIENTE](@id_rol_user INT, @nombre nvarchar(255), @apellido nvarchar(255), @id_documento int,
    @numero_documento numeric(18,0), @correo nvarchar(255),@telefono nvarchar(100),@domicilio_calle nvarchar(255),@domicilio_numero numeric(18,0),
    @domicilio_piso numeric(18,0), @domicilio_departamento nvarchar(50), @ciudad nvarchar(255), @pais int, @nacionalidad nvarchar(255), @fecha_nacimiento datetime)
AS
BEGIN

    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO] @id_rol_user, 10

	EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[INSERTAR_NUEVO_CLIENTE_SIN_VALIDACION] 
	    @nombre, @apellido, @id_documento, @numero_documento, @correo, @telefono, @domicilio_calle ,@domicilio_numero,
        @domicilio_piso, @domicilio_departamento, @ciudad, @pais, @nacionalidad, @fecha_nacimiento
END

GO

-- Modifica aun cliente
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[MODIFICAR_CLIENTE](@id_rol_user INT,@id_cliente INT,@nombre nvarchar(255), @apellido nvarchar(255),@id_documento int,
    @numero_documento numeric(18,0), @correo nvarchar(255),@telefono nvarchar(100),@domicilio_calle nvarchar(255),@domicilio_numero numeric(18,0),
    @domicilio_piso numeric(18,0), @domicilio_departamento nvarchar(50), @ciudad nvarchar(255), @pais int, @nacionalidad nvarchar(255), @fecha_nacimiento datetime, @estado_cliente BIT)
AS
BEGIN
    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO] @id_rol_user, 11
    UPDATE [EL_MONSTRUO_DEL_LAGO_MASER].[clientes]
    SET nombre_cliente = @nombre,apellido_cliente = @apellido,id_tipo_documento = @id_documento,numero_documento_cliente = @numero_documento,
    correo_cliente = @correo,telefono_cliente = @telefono,domicilio_calle_cliente = @domicilio_calle,domicilio_numero_cliente = @domicilio_numero,
    domicilio_piso_cliente = @domicilio_piso,domicilio_departamento_cliente = @domicilio_departamento ,ciudad_cliente = @ciudad ,
    id_pais = @pais,nacionalidad_cliente = @nacionalidad,fecha_nacimiento_cliente =  @fecha_nacimiento,estado_cliente = @estado_cliente
    WHERE id_cliente = @id_cliente 
END

GO

-- Borra un cliente
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[DESHABILITAR_CLIENTE]
        (@id_rol_user INT, @id_cliente INT)
AS
BEGIN

    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO] @id_rol_user, 12

    UPDATE [EL_MONSTRUO_DEL_LAGO_MASER].[clientes]
    SET estado_cliente = 0
    WHERE id_cliente = @id_cliente
END

GO

-- Filtra y obtiene los clientes de nuestro sistema, y los del sistema anterior
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_CLIENTES_COMPLETOS_FILTRADOS]
    (@id_documento int, @numero_documento numeric(18,0), @correo nvarchar(255))
AS
BEGIN
    SELECT TOP 100 id_cliente, nombre_cliente, apellido_cliente, id_tipo_documento, numero_documento_cliente, correo_cliente, telefono_cliente, domicilio_calle_cliente,
        domicilio_numero_cliente, domicilio_piso_cliente, domicilio_departamento_cliente, ciudad_cliente, id_pais, nacionalidad_cliente, fecha_nacimiento_cliente, estado_cliente 
	FROM [EL_MONSTRUO_DEL_LAGO_MASER].[clientes_completos]
    WHERE LOWER(correo_cliente) LIKE '%' + LOWER(@correo) + '%'
    AND (@id_documento = -1 OR id_tipo_documento = @id_documento)
    AND (@numero_documento = 0 OR CAST (numero_documento_cliente AS VARCHAR) LIKE '%' + CAST (@numero_documento AS VARCHAR) + '%')
    AND id_cliente != 0
    ORDER BY estado_cliente DESC, apellido_cliente, nombre_cliente
END

GO

-- Este procedure se usa cuando se re-registra un cliente existente previo a la migración
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[INSERTAR_CLIENTE_PREEXISTENTE]
    (@nombre_cliente NVARCHAR(255), @apellido_cliente NVARCHAR(255), @id_tipo_documento INT,
        @numero_documento_cliente NUMERIC(18,0), @correo_cliente NVARCHAR(255), @telefono_cliente NVARCHAR(100),
        @domicilio_calle_cliente NVARCHAR(255), @domicilio_numero_cliente NUMERIC(18,0), @domicilio_piso_cliente NUMERIC(18,0),
        @domicilio_departamento_cliente NVARCHAR(50), @ciudad_cliente NVARCHAR(255), @id_pais INT,
        @nacionalidad_cliente NVARCHAR(20), @fecha_nacimiento_cliente DATETIME)
AS
BEGIN
    DECLARE @id_reserva INT
        DECLARE @id_estadia INT
        DECLARE @id_cliente INT

    DECLARE cursor_clientes_preexistentes CURSOR FOR
        SELECT id_estadia, id_reserva
        FROM [EL_MONSTRUO_DEL_LAGO_MASER].[migracion_errores]
        WHERE apellido_cliente = @apellido_cliente
        AND domicilio_departamento_cliente = @domicilio_departamento_cliente
        AND domicilio_calle_cliente = @domicilio_calle_cliente
        AND fecha_nacimiento_cliente = @fecha_nacimiento_cliente
        AND nacionalidad_cliente = @nacionalidad_cliente
        AND nombre_cliente = @nombre_cliente
        AND domicilio_numero_cliente = @domicilio_numero_cliente
        AND domicilio_piso_cliente = @domicilio_piso_cliente

    BEGIN TRY
            BEGIN TRANSACTION

        -- Hacemos el insert a la tabla de clientes primero
        INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[clientes] (nombre_cliente, apellido_cliente, id_tipo_documento,
            numero_documento_cliente, correo_cliente, telefono_cliente, domicilio_calle_cliente, domicilio_numero_cliente,
            domicilio_piso_cliente, domicilio_departamento_cliente, ciudad_cliente, id_pais, nacionalidad_cliente,
            fecha_nacimiento_cliente)
        VALUES (@nombre_cliente, @apellido_cliente, @id_tipo_documento, @numero_documento_cliente, @correo_cliente,
            @telefono_cliente, @domicilio_calle_cliente, @domicilio_numero_cliente, @domicilio_piso_cliente,
            @domicilio_departamento_cliente, @ciudad_cliente, @id_pais, @nacionalidad_cliente, @fecha_nacimiento_cliente)

        SET @id_cliente = SCOPE_IDENTITY();

        OPEN cursor_clientes_preexistentes
        FETCH cursor_clientes_preexistentes INTO @id_estadia, @id_reserva

        WHILE (@@FETCH_STATUS = 0) BEGIN
                    IF (@id_reserva IS NOT NULL) BEGIN
                UPDATE [EL_MONSTRUO_DEL_LAGO_MASER].[reservas]
                SET id_cliente = @id_cliente
                WHERE id_reserva = @id_reserva
            END
            IF (@id_estadia IS NOT NULL
                AND NOT EXISTS (SELECT *
                                FROM [EL_MONSTRUO_DEL_LAGO_MASER].[clientesXestadias]
                                WHERE id_cliente = @id_cliente
                                AND id_estadia = @id_estadia)) BEGIN
                INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[clientesXestadias]
                    (id_cliente, id_estadia)
                VALUES (@id_cliente, @id_estadia)
            END

            DELETE FROM [EL_MONSTRUO_DEL_LAGO_MASER].[migracion_errores]
            WHERE CURRENT OF cursor_clientes_preexistentes

            FETCH cursor_clientes_preexistentes INTO @id_estadia, @id_reserva
        END

        SELECT @id_cliente

        COMMIT TRANSACTION
        CLOSE cursor_clientes_preexistentes
        DEALLOCATE cursor_clientes_preexistentes
    END TRY
    BEGIN CATCH
            ROLLBACK TRANSACTION

        IF CURSOR_STATUS('global', 'cursor_clientes_preexistentes') = 1 BEGIN
            CLOSE cursor_clientes_preexistentes
        END
        DEALLOCATE cursor_clientes_preexistentes;

                THROW
    END CATCH
END

GO

-- Obtiene el listado de regimenes
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_REGIMENES]
AS
BEGIN
    SELECT id_regimen, descripcion_regimen, precio_base_regimen, estado_regimen
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[regimenes]
END

GO

-- Tipo necesario para los regimenes
CREATE TYPE [EL_MONSTRUO_DEL_LAGO_MASER].[listaDeRegimenes] AS TABLE
    (id_regimen INT)

GO

-- Agrega un nuevo hotel
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[AGREGAR_NUEVO_HOTEL](@id_rol_user INT, @nombre_hotel NVARCHAR(255), @correo_hotel NVARCHAR(255),
 @telefono_hotel NVARCHAR(100), @ciudad_hotel NVARCHAR(255), @domicilio_calle_hotel NVARCHAR(255), @domicilio_numero_hotel NUMERIC(18,0),
 @cantidad_estrellas_hotel NUMERIC(18,0), @id_pais INT, @fecha_creacion_hotel DATETIME, @recarga_por_estrellas_hotel NUMERIC(18,0), @regimenes EL_MONSTRUO_DEL_LAGO_MASER.listaDeRegimenes READONLY)
AS
BEGIN
    DECLARE @id_reg   INT 
    DECLARE @id_hotel INT

    DECLARE cursor_regimenes CURSOR FOR
        SELECT id_regimen
        FROM  @regimenes
    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO] @id_rol_user, 13
    
	BEGIN TRY
		BEGIN TRANSACTION
		INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[hoteles]
		(nombre_hotel, correo_hotel, telefono_hotel, ciudad_hotel, domicilio_calle_hotel, domicilio_numero_hotel,
		cantidad_estrellas_hotel, id_pais, fecha_creacion_hotel, recarga_por_estrellas_hotel)
		VALUES (@nombre_hotel, @correo_hotel, @telefono_hotel, @ciudad_hotel, @domicilio_calle_hotel, @domicilio_numero_hotel,
		@cantidad_estrellas_hotel, @id_pais, @fecha_creacion_hotel, @recarga_por_estrellas_hotel)

		SET @id_hotel = SCOPE_IDENTITY();

		OPEN cursor_regimenes
			FETCH cursor_regimenes INTO @id_reg
			WHILE(@@FETCH_STATUS = 0)
			BEGIN
				INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[hotelesXregimenes]
					(id_hotel,id_regimen)
				VALUES (@id_hotel, @id_reg)
				FETCH cursor_regimenes INTO @id_reg
			END
		COMMIT TRANSACTION
		CLOSE cursor_regimenes
		DEALLOCATE cursor_regimenes
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION

        IF CURSOR_STATUS('global', 'cursor_regimenes') = 1 BEGIN
            CLOSE cursor_regimenes
        END
        DEALLOCATE cursor_regimenes;

        THROW
	END CATCH
	
END

GO

-- Trae los hoteles con los filtros posibles.
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_HOTELES_FILTRADOS](@nombre nvarchar(255), @estrellas numeric(18,0),
    @ciudad nvarchar(255), @id_pais int)
AS
BEGIN

    SELECT id_hotel, nombre_hotel, correo_hotel, telefono_hotel, ciudad_hotel,
	   domicilio_calle_hotel, domicilio_numero_hotel, cantidad_estrellas_hotel, id_pais, 
           fecha_creacion_hotel, recarga_por_estrellas_hotel
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[hoteles]
    WHERE LOWER(nombre_hotel) LIKE '%' + LOWER(@nombre) + '%'
    AND (@estrellas = 0 OR cantidad_estrellas_hotel = @estrellas)
    AND LOWER(ciudad_hotel) LIKE '%' + LOWER(@ciudad) + '%'
    AND (@id_pais = -1 OR id_pais = @id_pais)
END

GO

-- Obtiene los regimenes pero de un cierto hotel (solo el ID)
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_REGIMENES_DE_UN_HOTEL] (@id_hotel INT)
AS
BEGIN
    SELECT id_regimen
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[hotelesXregimenes]
    WHERE id_hotel = @id_hotel
END

GO

-- Ingresa un nuevo cierre temporal
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[INSERTAR_CIERRE_TEMPORAL_HOTEL]
    (@id_rol_user INT, @inicio DATETIME, @fin DATETIME, @id_hotel INT, @motivo NVARCHAR(2500))
AS
BEGIN
    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO] @id_rol_user, 15

	IF (EXISTS(SELECT * FROM [EL_MONSTRUO_DEL_LAGO_MASER].[cierres_temporales_hotel]
	           WHERE (@inicio <= fecha_fin_cierre_temporal_hotel)
			   AND (fecha_inicio_cierre_temporal_hotel <= @fin)
                           AND id_hotel = @id_hotel))
	BEGIN
		RAISERROR('50001 - Ese hotel ya tiene un cierre temporal durante ese margen de fechas', 20, 1) WITH LOG 
	END

	INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[cierres_temporales_hotel]
	VALUES (@inicio, @fin, @id_hotel, @motivo)
END

GO

-- Este procedure modifica un hotel
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[MODIFICAR_HOTEL] (@id_rol_user INT, @id_hotel INT, @nombre_hotel NVARCHAR(255), @correo_hotel NVARCHAR(255),
    @telefono_hotel NVARCHAR(100), @ciudad_hotel NVARCHAR(255), @domicilio_calle_hotel NVARCHAR(255), @domicilio_numero_hotel NVARCHAR(255),
    @cantidad_estrellas_hotel NUMERIC(18,0), @id_pais INT, @fecha_creacion_hotel DATETIME, @recarga_por_estrellas_hotel NUMERIC(18,0), @regimenes EL_MONSTRUO_DEL_LAGO_MASER.listaDeRegimenes READONLY)
AS
BEGIN
    DECLARE @id_reg INT
    DECLARE cursor_regimenes CURSOR FOR
         SELECT id_regimen
         FROM @regimenes

    -- Comprobamos si el usuario tiene la funcionalidad de modificar hoteles
    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO] @id_rol_user, 14
	
	BEGIN TRY
	    BEGIN TRANSACTION
        -- Actualizamos al hotel
        UPDATE [EL_MONSTRUO_DEL_LAGO_MASER].[hoteles]
        SET nombre_hotel = @nombre_hotel, correo_hotel = @correo_hotel, telefono_hotel = @telefono_hotel, ciudad_hotel = @ciudad_hotel, 
            domicilio_calle_hotel = @domicilio_calle_hotel, domicilio_numero_hotel = @domicilio_numero_hotel, cantidad_estrellas_hotel = @cantidad_estrellas_hotel, 
            id_pais = @id_pais, fecha_creacion_hotel = @fecha_creacion_hotel, recarga_por_estrellas_hotel = @recarga_por_estrellas_hotel
        WHERE id_hotel = @id_hotel
	    
        --Borramos todos los regimenes del hotel
        DELETE FROM [EL_MONSTRUO_DEL_LAGO_MASER].[hotelesXregimenes]
        WHERE id_hotel = @id_hotel
	    
        --Agregamos los nuevos regimenes con un cursor.
        OPEN cursor_regimenes
        FETCH cursor_regimenes INTO @id_reg
        WHILE (@@FETCH_STATUS = 0) BEGIN
            INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[hotelesXregimenes]
                (id_hotel,id_regimen)
            VALUES(@id_hotel,@id_reg)
            FETCH cursor_regimenes INTO @id_reg
        END

		COMMIT TRANSACTION
        CLOSE cursor_regimenes
        DEALLOCATE cursor_regimenes
	END TRY
	BEGIN CATCH
	    ROLLBACK TRANSACTION

        IF CURSOR_STATUS('global', 'cursor_regimenes') = 1 BEGIN
            CLOSE cursor_regimenes
        END
        DEALLOCATE cursor_regimenes;
	END CATCH
END

GO


-- Obtiene el listado de tipos de habitaciòn
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_TIPOS_HABITACION]
AS
BEGIN
    SELECT id_tipo_habitacion, descripcion_tipo_habitacion, porcentual_tipo_habitacion, cantidad_huespedes_tipo_habitacion
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[tipos_habitacion]
END

GO

-- Inserta una habitación a la tabla de habitaciones
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[INSERTAR_HABITACION] (@id_rol_user INT,@id_hotel INT, @numero_habitacion numeric(18,0), @piso_habitacion numeric(18,0),
    @ubicacion_habitacion nvarchar(50), @id_tipo_habitacion INT, @descripcion_habitacion NVARCHAR(255))
AS
BEGIN
    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO] @id_rol_user, 16

    INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[habitaciones]
        (id_hotel, numero_habitacion, piso_habitacion, ubicacion_habitacion, id_tipo_habitacion, descripcion_habitacion)
    VALUES(@id_hotel, @numero_habitacion, @piso_habitacion, @ubicacion_habitacion, @id_tipo_habitacion, @descripcion_habitacion)
END

GO

-- Usado para obtener las habitaciones filtradas
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_HABITACIONES_FILTRADAS](@id_hotel INT, @numero_habitacion numeric(18,0), 
    @piso_habitacion numeric(18,0), @id_tipo_habitacion INT)
AS
BEGIN
    SELECT id_habitacion, numero_habitacion, piso_habitacion, ubicacion_habitacion, id_tipo_habitacion, descripcion_habitacion
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[habitaciones]
    WHERE id_hotel = @id_hotel 
    AND (@numero_habitacion = 0 OR CAST(numero_habitacion AS NVARCHAR) LIKE '%' + CAST(@numero_habitacion AS NVARCHAR) + '%')
    AND (@piso_habitacion = 0 OR CAST(piso_habitacion AS NVARCHAR) LIKE '%' + CAST(@piso_habitacion AS NVARCHAR) + '%')
    AND (@id_tipo_habitacion = -1 OR id_tipo_habitacion = @id_tipo_habitacion)
END

GO

-- Modifica un hotel existente
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[MODIFICAR_HABITACION] (@id_rol_user INT, @id_habitacion INT, 
    @numero_habitacion numeric(18,0), @piso_habitacion numeric(18,0), @ubicacion_habitacion NVARCHAR(50), @descripcion_habitacion NVARCHAR(255))
AS
BEGIN
    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO] @id_rol_user, 17

    UPDATE [EL_MONSTRUO_DEL_LAGO_MASER].[habitaciones]
    SET numero_habitacion = @numero_habitacion, piso_habitacion = @piso_habitacion, ubicacion_habitacion = @ubicacion_habitacion, 
        descripcion_habitacion = @descripcion_habitacion
    WHERE id_habitacion = @id_habitacion
END

GO

-- Agrega un cierre temporal de la habitación
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[INSERTAR_CIERRE_TEMPORAL_HABITACION]
    (@id_rol_user INT, @inicio DATETIME, @fin DATETIME, @id_habitacion INT, @motivo NVARCHAR(2500))
AS
BEGIN
    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO] @id_rol_user, 18

        IF (EXISTS(SELECT * FROM [EL_MONSTRUO_DEL_LAGO_MASER].[cierres_temporales_habitacion]
                   WHERE (@inicio <= fecha_fin_cierre_temporal_habitacion)
                           AND (fecha_inicio_cierre_temporal_habitacion <= @fin)
                           AND id_habitacion = @id_habitacion))
        BEGIN
                RAISERROR('50001 - Esa habitación ya tiene un cierre temporal durante ese margen de fechas', 20, 1) WITH LOG
        END

        INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[cierres_temporales_habitacion]
        VALUES (@inicio, @fin, @id_habitacion, @motivo)
END

GO

-- Obtiene los regimenes activos de un hotel
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_REGIMENES_ACTIVOS_DE_HOTEL] (@id_hotel INT)
AS
BEGIN
    SELECT r.id_regimen, descripcion_regimen, precio_base_regimen, estado_regimen
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[regimenes] r
	JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[hotelesXregimenes] hXr
	ON r.id_regimen = hXr.id_regimen
	WHERE estado_regimen = 1
	AND id_hotel = @id_hotel
END

GO

-- Este procedure se encarga de actualizar las reservas vencidas por no show (se ejecuta cuando se intenta ingresar una reserva)
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[CANCELAR_RESERVAS_VENCIDAS] (@today DATETIME)
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION
		
		-- Primero updateo las reservas que estén "activas"
		-- Si ya pasó el día inicial, la seteamos en 5
		UPDATE [EL_MONSTRUO_DEL_LAGO_MASER].[reservas]
		SET id_estado_reserva = 5
		FROM [EL_MONSTRUO_DEL_LAGO_MASER].[reservas] r
		LEFT JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[estadias] e ON e.id_reserva = r.id_reserva
		WHERE id_estadia IS NULL
		AND @today > fecha_inicio_reserva
		AND id_estado_reserva IN (1, 2)

		-- Finalmente para las desconocidas
		-- (generadas por la migración)
		UPDATE [EL_MONSTRUO_DEL_LAGO_MASER].[reservas]
		SET id_estado_reserva = 8
		FROM [EL_MONSTRUO_DEL_LAGO_MASER].[reservas] r
		LEFT JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[estadias] e
		ON e.id_reserva = r.id_reserva
		WHERE id_estadia IS NULL
		AND @today > fecha_inicio_reserva
		AND id_estado_reserva = 7

		COMMIT TRANSACTION
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION
		RAISERROR('No se pudo hacer update de reservas vencidas', 18, 1) WITH LOG
	END CATCH
END

GO

-- Este procedure obtiene las habitaciones disponibles para cierta reserva
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_HABITACIONES_DISPONIBLES_RESERVA]
    (@id_rol INT, @today DATETIME, @fecha_inicio DATETIME, @fecha_fin DATETIME, @id_hotel INT, @id_reserva INT)
AS
BEGIN

    -- Validación de seguridad
    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO] @id_rol, 1

    -- Actualizo las reservas vencidas para que estén disponibles
    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[CANCELAR_RESERVAS_VENCIDAS] @today

        -- Si contiene al menos una ROW, el hotel estará cerrado
    IF (EXISTS (SELECT fecha_inicio_cierre_temporal_hotel, fecha_fin_cierre_temporal_hotel
                FROM EL_MONSTRUO_DEL_LAGO_MASER.cierres_temporales_hotel
                WHERE @fecha_inicio <= fecha_fin_cierre_temporal_hotel
                AND @fecha_fin >= fecha_inicio_cierre_temporal_hotel
                AND id_hotel = @id_hotel)) BEGIN
        SELECT -1 id_habitacion
                RETURN
    END

        -- Todas las habitaciones disponibles
                SELECT * FROM EL_MONSTRUO_DEL_LAGO_MASER.habitaciones
                WHERE id_hotel = @id_hotel
        EXCEPT -- Excepto las que estén reservadas
                SELECT h.* FROM EL_MONSTRUO_DEL_LAGO_MASER.habitaciones h
                JOIN EL_MONSTRUO_DEL_LAGO_MASER.reservasXhabitaciones rXh ON h.id_habitacion = rXh.id_habitacion
                JOIN EL_MONSTRUO_DEL_LAGO_MASER.reservas r ON rXh.id_reserva = r.id_reserva
                WHERE id_hotel = @id_hotel
                AND rXh.id_reserva <> @id_reserva
                AND @fecha_inicio < fecha_fin_reserva
                AND @fecha_fin > fecha_inicio_reserva
                AND id_estado_reserva IN (1, 2, 6, 7)
        EXCEPT -- Y las que estén cerradas temporalmente
                SELECT h.* FROM EL_MONSTRUO_DEL_LAGO_MASER.habitaciones h
                JOIN EL_MONSTRUO_DEL_LAGO_MASER.cierres_temporales_habitacion c ON h.id_habitacion = c.id_habitacion
                WHERE @fecha_inicio <= fecha_fin_cierre_temporal_habitacion
                AND @fecha_fin >= fecha_inicio_cierre_temporal_habitacion
                AND id_hotel = @id_hotel
END

GO

-- Obtengo el ID del regimen all inclusive
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_REGIMEN_ALL_INCLUSIVE]
AS
BEGIN
	SELECT id_regimen
	FROM [EL_MONSTRUO_DEL_LAGO_MASER].[regimenes]
	WHERE descripcion_regimen = 'All inclusive'
END

GO

-- Esta vista devuelve los clientes totales (los migrados + los que tienen errores)
CREATE VIEW [EL_MONSTRUO_DEL_LAGO_MASER].[clientes_completos]
AS
	SELECT * FROM [EL_MONSTRUO_DEL_LAGO_MASER].[clientes]
        WHERE id_cliente != 0
	UNION
	SELECT DISTINCT
		-1 id_cliente,
		nombre_cliente, 
		apellido_cliente, 
		6 id_tipo_documento, 
		numero_documento_cliente, 
		correo_cliente, 
		null telefono_cliente, 
		domicilio_calle_cliente, 
		domicilio_numero_cliente, 
		domicilio_piso_cliente, 
		domicilio_departamento_cliente, 
		null ciudad_cliente, 
		null id_pais, 
		nacionalidad_cliente, 
		fecha_nacimiento_cliente,
		0 estado_cliente
	FROM [EL_MONSTRUO_DEL_LAGO_MASER].[migracion_errores]
GO

-- Este procedure valida que no haya un cliente con dado documento
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_DOCUMENTO_UNICO_CLIENTE]
    (@id_tipo_documento INT, @numero_documento_cliente NUMERIC(18,0))
AS
BEGIN
    IF (EXISTS (SELECT * FROM [EL_MONSTRUO_DEL_LAGO_MASER].[clientes]
                WHERE id_tipo_documento = @id_tipo_documento
                AND numero_documento_cliente = @numero_documento_cliente))
    BEGIN
	    SELECT 0
    END ELSE BEGIN
	    SELECT 1
    END
END

GO

-- Este procedure valida si hay un cliente con ese correo
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_CORREO_UNICO_CLIENTE]
    (@correo NVARCHAR(255))
AS
BEGIN
    IF (EXISTS (SELECT * FROM [EL_MONSTRUO_DEL_LAGO_MASER].[clientes]
                WHERE correo_cliente = @correo))
    BEGIN
	    SELECT 0 
    END ELSE BEGIN
	    SELECT 1
    END
END

GO

CREATE TYPE [EL_MONSTRUO_DEL_LAGO_MASER].[listaDeHabitaciones] AS TABLE
(id_habitacion INT)

GO

-- Este procedimiento hace el insert de la reserva al sistema
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[INSERTAR_RESERVA]
    (@id_rol_user INT, @fecha_realizacion DATETIME, @fecha_inicio DATETIME, @fecha_fin DATETIME,
    @id_cliente INT, @id_regimen INT, @habitaciones EL_MONSTRUO_DEL_LAGO_MASER.listaDeHabitaciones READONLY,
    @id_usuario INT)
AS
BEGIN
    DECLARE @id_reserva     INT
    DECLARE @id_habitacion  INT

    DECLARE cursor_habitaciones CURSOR FOR
        SELECT id_habitacion
        FROM @habitaciones

    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO] @id_rol_user, 1

    IF (EXISTS(SELECT * FROM [EL_MONSTRUO_DEL_LAGO_MASER].[clientes]
               WHERE id_cliente = @id_cliente
               AND estado_cliente = 0)) BEGIN
        RAISERROR('El cliente está deshabilitado. No puede realizar reservas', 20, 1) WITH LOG
    END

    BEGIN TRY
        BEGIN TRANSACTION
            -- Primero, insertamos la nueva reserva
            INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[reservas]
                (fecha_realizacion_reserva, fecha_inicio_reserva, fecha_fin_reserva, id_cliente, id_regimen, id_estado_reserva)
            VALUES (@fecha_realizacion, @fecha_inicio, @fecha_fin, @id_cliente, @id_regimen, 1)

            -- Seteamos el ID reserva
            SET @id_reserva = SCOPE_IDENTITY()

            -- Ahora insertamos la transaccion en el log de generacion y modificacion
            INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[generacion_modificacion_reservas]
                (id_reserva, id_usuario, tipo_generacion_modificacion_reserva, fecha_generacion_modificacion_reserva)
            VALUES (@id_reserva, @id_usuario, 'G', @fecha_realizacion)

            -- Finalmente, insertamos en clientes por habitaciones haciendo un loop del cursor
            OPEN cursor_habitaciones
            FETCH cursor_habitaciones INTO @id_habitacion

            WHILE (@@FETCH_STATUS = 0) BEGIN
                INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[reservasXhabitaciones]
                    (id_reserva, id_habitacion)
                VALUES (@id_reserva, @id_habitacion)

                FETCH cursor_habitaciones INTO @id_habitacion
            END
        COMMIT TRANSACTION

        -- Hago un select para poder tomarlo desde la aplicación
        SELECT @id_reserva

        CLOSE cursor_habitaciones
        DEALLOCATE cursor_habitaciones
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION

        IF CURSOR_STATUS('global', 'cursor_habitaciones') = 1 BEGIN
            CLOSE cursor_habitaciones
        END
        DEALLOCATE cursor_habitaciones;

        THROW
    END CATCH
END

GO

-- Este procedure obtiene información de una reserva
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_RESERVA]
    (@id_reserva INT, @today DATETIME)
AS
BEGIN
    SELECT fecha_realizacion_reserva, fecha_inicio_reserva, fecha_fin_reserva, id_regimen
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[reservas] r
    LEFT JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[estadias] e
        ON r.id_reserva = e.id_reserva
    WHERE r.id_reserva = @id_reserva
    AND id_estado_reserva IN (1, 2, 7)
    AND fecha_inicio_reserva > @today 
    AND id_estadia IS NULL
END

GO

-- Este procedure obtiene los tipos de habitación de una reserva
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_TIPOS_HABITACION_RESERVA]
    (@id_reserva INT)
AS
BEGIN
    SELECT h.id_tipo_habitacion, descripcion_tipo_habitacion, porcentual_tipo_habitacion, cantidad_huespedes_tipo_habitacion 
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[reservasXhabitaciones] rxh
    JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[habitaciones] h
        ON rxh.id_habitacion = h.id_habitacion
    JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[tipos_habitacion] th
        ON h.id_tipo_habitacion = th.id_tipo_habitacion
    WHERE id_reserva = @id_reserva
END

GO

-- Obtengo el ID de hotel relacionado de una reserva
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_HOTEL_DE_RESERVA]
    (@id_reserva INT)
AS
BEGIN
    SELECT id_hotel FROM [EL_MONSTRUO_DEL_LAGO_MASER].[reservas] r
    LEFT JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[reservasXhabitaciones] rXh
        ON r.id_reserva = rXh.id_reserva
    LEFT JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[habitaciones] h
        ON rXh.id_habitacion = h.id_habitacion
    WHERE r.id_reserva = @id_reserva
END

GO

-- Modifica una reserva con datos nuevos
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[MODIFICAR_RESERVA]
    (@id_usuario INT, @id_rol_user INT, @fecha_inicio DATETIME, @fecha_fin DATETIME, @id_regimen INT,
    @id_reserva INT, @fecha_hoy DATETIME, @habitaciones EL_MONSTRUO_DEL_LAGO_MASER.listaDeHabitaciones READONLY)
AS
BEGIN
    DECLARE @id_habitacion  INT
    DECLARE cursor_habitaciones CURSOR FOR
        SELECT id_habitacion
        FROM @habitaciones

    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO] @id_rol_user, 2

    BEGIN TRY
        BEGIN TRANSACTION
        UPDATE [EL_MONSTRUO_DEL_LAGO_MASER].[reservas]
        SET fecha_inicio_reserva = @fecha_inicio, fecha_fin_reserva = @fecha_fin, 
            id_estado_reserva = 2, id_regimen = @id_regimen
        WHERE id_reserva = @id_reserva

        DELETE FROM [EL_MONSTRUO_DEL_LAGO_MASER].[reservasXhabitaciones]
        WHERE id_reserva = @id_reserva 

        OPEN cursor_habitaciones
        FETCH cursor_habitaciones INTO @id_habitacion
        WHILE (@@FETCH_STATUS = 0) BEGIN
            INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[reservasXhabitaciones]
                (id_reserva, id_habitacion)
            VALUES (@id_reserva, @id_habitacion)

            FETCH cursor_habitaciones INTO @id_habitacion
        END

        CLOSE cursor_habitaciones
        DEALLOCATE cursor_habitaciones

        INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[generacion_modificacion_reservas]
            (fecha_generacion_modificacion_reserva, tipo_generacion_modificacion_reserva, id_usuario, id_reserva)
        VALUES (@fecha_hoy, 'M', @id_usuario, @id_reserva)

        COMMIT TRANSACTION
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION

        IF CURSOR_STATUS('global', 'cursor_habitaciones') = 1 BEGIN
            CLOSE cursor_habitaciones
        END
        DEALLOCATE cursor_habitaciones;

        THROW
    END CATCH
END

GO

-- Cancela una reserva existente
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[CANCELAR_RESERVA]
    (@id_rol_user INT, @id_reserva INT, @motivo_cancelacion_reserva NVARCHAR(2500),
    @fecha_cancelacion_reserva DATETIME, @id_usuario INT)
AS
BEGIN
    DECLARE @id_estado_reserva INT
    DECLARE @id_usuario_dummy INT

    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO] @id_rol_user, 3

    BEGIN TRY
        BEGIN TRANSACTION

        -- Con este bloque obtenemos el id del usuario dummy
        CREATE TABLE #dummyTable (id_usuario_dummy INT)

        insert into #dummyTable
        EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_USUARIO_DUMMY]

        SELECT @id_usuario_dummy = id_usuario_dummy 
        FROM #dummyTable

        DROP TABLE #dummyTable
        -- Ya obtuvimos el id del usuario dummy

        INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[cancelaciones_reserva]
            (id_reserva, motivo_cancelacion_reserva,fecha_cancelacion_reserva,id_usuario)
        VALUES (@id_reserva, @motivo_cancelacion_reserva, @fecha_cancelacion_reserva, @id_usuario)

        IF (@id_usuario = @id_usuario_dummy) BEGIN
            SET @id_estado_reserva = 4
        END ELSE BEGIN
            SET @id_estado_reserva = 3
        END

        UPDATE [EL_MONSTRUO_DEL_LAGO_MASER].[reservas]
        SET id_estado_reserva = @id_estado_reserva
        WHERE id_reserva = @id_reserva

        COMMIT TRANSACTION
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION
        THROW
    END CATCH
END

GO

-- Este procedure obtiene las reservas que se puede ingresar/cerrar una estadia
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_RESERVA_APTA_ESTADIA]
    (@id_rol_user INT, @id_usuario INT, @id_reserva INT, @today DATETIME)
AS
BEGIN

    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[CANCELAR_RESERVAS_VENCIDAS] @today

    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO] @id_rol_user, 22

    SELECT DISTINCT fecha_realizacion_reserva, fecha_inicio_reserva, fecha_fin_reserva, id_regimen, id_estado_reserva
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[reservas] r
    LEFT JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[estadias] e
        ON r.id_reserva = e.id_reserva
    LEFT JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[reservasXhabitaciones] rh
        ON r.id_reserva = rh.id_reserva
    LEFT JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[habitaciones] h
        ON rh.id_habitacion = h.id_habitacion
    WHERE r.id_reserva = @id_reserva
    AND (
        (id_estado_reserva IN (1, 2, 7) AND fecha_inicio_reserva = @today AND id_estadia IS NULL)
        OR
        (id_estado_reserva = 6 AND id_estadia IS NOT NULL AND fecha_egreso_estadia IS NULL)
    )
    AND id_hotel IN (SELECT id_hotel 
                     FROM [EL_MONSTRUO_DEL_LAGO_MASER].[usuariosXhoteles]
                     WHERE id_usuario = @id_usuario)
END

GO

-- Obtiene las habitaciones de una reserva
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_HABITACIONES_DE_RESERVA]
    (@id_reserva INT)
AS
BEGIN
    SELECT h.id_habitacion, numero_habitacion, piso_habitacion, 
        ubicacion_habitacion, id_tipo_habitacion, descripcion_habitacion
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[habitaciones] h
    JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[reservasXhabitaciones] rXh
        ON h.id_habitacion = rXh.id_habitacion
    WHERE rXh.id_reserva = @id_reserva
END

GO

-- Este procedure obtiene la estadìa relacionada a la reserva
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_ESTADIA_DE_RESERVA]
    (@id_reserva INT)
AS
BEGIN 
    SELECT id_estadia, fecha_ingreso_estadia, fecha_egreso_estadia 
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[estadias]
    WHERE id_reserva = @id_reserva
END

GO

-- Este procedure devuelve un cliente relacionado a la reserva
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_CLIENTE_DE_RESERVA]
    (@id_reserva INT)
AS
BEGIN 
    SELECT r.id_cliente, nombre_cliente, apellido_cliente, id_tipo_documento,
        numero_documento_cliente, correo_cliente
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[reservas] r
    JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[clientes] c
        ON r.id_cliente = c.id_cliente
    WHERE id_reserva = @id_reserva
END

GO

-- Este tipo se usa para el procedure que inserta los clientes x estadias
CREATE TYPE [EL_MONSTRUO_DEL_LAGO_MASER].[listaDeClientes] AS TABLE
    (id_cliente INT)

GO

-- Este procedure hace el ingreso de una estadia
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[INGRESAR_ESTADIA]
    (@id_rol_user INT, @id_reserva INT, @id_usuario_ingreso INT, @fecha_ingreso_estadia DATETIME,
    @clientes EL_MONSTRUO_DEL_LAGO_MASER.listaDeClientes READONLY )
AS
BEGIN

    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO] @id_rol_user, 22

    DECLARE @id_cliente INT
    DECLARE @id_estadia INT

    DECLARE cursor_clientes CURSOR FOR
        SELECT id_cliente
        FROM @clientes

    BEGIN TRY
        BEGIN TRANSACTION

        INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[estadias]
            (id_reserva, id_usuario_ingreso, fecha_ingreso_estadia)
        VALUES(@id_reserva, @id_usuario_ingreso, @fecha_ingreso_estadia)

        SET @id_estadia = SCOPE_IDENTITY()

        OPEN cursor_clientes
        FETCH cursor_clientes INTO @id_cliente
        WHILE (@@FETCH_STATUS = 0) BEGIN
            INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[clientesXestadias]
                (id_cliente, id_estadia)
            VALUES(@id_cliente, @id_estadia)

            FETCH cursor_clientes INTO @id_cliente
        END

        UPDATE [EL_MONSTRUO_DEL_LAGO_MASER].[reservas]
        SET id_estado_reserva = 6
        WHERE id_reserva = @id_reserva

        COMMIT TRANSACTION

        SELECT @id_estadia

        CLOSE cursor_clientes
        DEALLOCATE cursor_clientes
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION

        IF CURSOR_STATUS('global', 'cursor_clientes') = 1 BEGIN
            CLOSE cursor_clientes
        END
        DEALLOCATE cursor_clientes;

        THROW
    END CATCH
END

GO

-- Este procedure hace el egreso de la estadia
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[EGRESAR_ESTADIA]
    (@id_rol_user INT, @id_estadia  INT, @id_usuario_egreso INT, @fecha_egreso_estadia DATETIME)
AS
BEGIN

      EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO] @id_rol_user, 22

      UPDATE [EL_MONSTRUO_DEL_LAGO_MASER].[estadias]
      SET fecha_egreso_estadia = @fecha_egreso_estadia, id_usuario_egreso = @id_usuario_egreso
      WHERE id_estadia = @id_estadia

END

GO

-- Este procedure obtiene los clientes de una estadia
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_CLIENTES_ESTADIA]
    (@id_estadia INT)
AS
BEGIN
    SELECT c.id_cliente, nombre_cliente, apellido_cliente,
        id_tipo_documento, numero_documento_cliente, correo_cliente
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[clientesXestadias] cxe 
    JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[clientes] c 
        ON c.id_cliente = cxe.id_cliente
    WHERE cxe.id_estadia = @id_estadia 
END

GO

-- Este procedure se usa para ver que reservas estan en un periodo (sirve para no cerrar un hotel si tiene reservas en un periodo)
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_CANTIDAD_RESERVAS_EN_PERIODO_HOTEL]
    (@fecha_inicio DATETIME, @fecha_fin DATETIME, @id_hotel INT)
AS
BEGIN
    SELECT COUNT(r.id_reserva)
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[reservas] r 
    JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[reservasXhabitaciones] rxh 
        ON (r.id_reserva = rxh.id_reserva) 
    JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[habitaciones] h 
        ON (h.id_habitacion = rxh.id_habitacion)
    WHERE id_hotel = @id_hotel 
    AND @fecha_inicio <= fecha_fin_reserva
    AND fecha_inicio_reserva <= @fecha_fin
    AND id_estado_reserva IN (1, 2, 6, 7)
END

GO

-- Este procedure revisa si hay una habitacion ocupada en cierto periodo (usado para cierre temporal de hoteles)
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[HABITACION_RESERVADA_EN_INTERVALO]
    (@fecha_inicio DATETIME, @fecha_fin DATETIME, @id_habitacion INT)
AS
BEGIN
    SELECT COUNT(r.id_reserva)
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[reservasXhabitaciones] rXh
    JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[reservas] r 
        ON (r.id_reserva = rXh.id_reserva)
    WHERE id_habitacion = @id_habitacion 
    AND @fecha_inicio <= fecha_fin_reserva
    AND fecha_inicio_reserva <= @fecha_fin
    AND id_estado_reserva IN (1, 2, 6, 7)
END

GO

-- Este procedure obtiene los regimenes de las reservas de un hotel, para validar que no 
-- estemos borrando un regimen siendo usaado
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[REGIMENES_USADOS_POR_RESERVAS_DE_HOTEL](@fecha_hoy DATETIME, @id_hotel INT)
AS
BEGIN
    SELECT DISTINCT r.id_regimen, descripcion_regimen, precio_base_regimen, estado_regimen
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[reservas] r
    JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[reservasXhabitaciones] rh
        ON r.id_reserva = rh.id_reserva
    JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[habitaciones] h
        ON rh.id_habitacion = h.id_habitacion
    JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[regimenes] rr
        ON r.id_regimen = rr.id_regimen
    WHERE fecha_fin_reserva >= @fecha_hoy 
    AND id_hotel = @id_hotel 
    AND id_estado_reserva IN (1, 2, 6, 7)
END

GO

-- Este procedure obtiene la habitaaciones de una estadia (sirve paraa consumibles de las habitaciones)
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_HABITACIONES_DE_ESTADIA]
    (@id_estadia INT)
AS
BEGIN
    DECLARE @id_reserva INT
    
    SELECT @id_reserva = id_reserva
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[estadias]
    WHERE id_estadia = @id_estadia

    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_HABITACIONES_DE_RESERVA] @id_reserva
END

GO

-- Este procedure obtiene las propiedades de una estadia
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_ESTADIA]
    (@id_rol_user INT, @id_estadia INT)
AS
BEGIN

    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO] @id_rol_user, 23

    SELECT fecha_ingreso_estadia, fecha_egreso_estadia, consumos_cerrados
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[estadias]
    WHERE id_estadia = @id_estadia
END

GO

-- Este procedure obtiene todos los consumibles por un filtro
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_CONSUMIBLES_FILTRADOS]
    (@descripcion NVARCHAR(255))
AS
BEGIN
    SELECT id_consumible, precio_consumible, descripcion_consumible
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[consumibles]
    WHERE LOWER(descripcion_consumible) LIKE '%' + LOWER(@descripcion) + '%'
END

GO

-- Este procedure ingresa un consumo y devuelve su ID
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[AGREGAR_CONSUMO]
    (@id_rol_user INT, @id_consumible INT, @id_estadia INT,
    @id_habitacion INT, @fecha_consumo DATETIME, @cantidad_consumo INT)
AS
BEGIN
    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO] @id_rol_user, 23

    INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[consumos]
        (id_consumible, id_estadia,id_habitacion, fecha_consumo, cantidad_consumo)
    VALUES(@id_consumible, @id_estadia, @id_habitacion, @fecha_consumo, @cantidad_consumo)

    SELECT SCOPE_IDENTITY() id_consumo
END

GO

-- Este procedure obtiene la información de un consumo para listarla
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_CONSUMOS_DE_ESTADIA]
    (@id_estadia INT)
AS
BEGIN
    SELECT id_consumo, fecha_consumo, h.id_habitacion, numero_habitacion, 
        c.id_consumible, descripcion_consumible, precio_consumible, cantidad_consumo
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[consumos] c 
    JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[habitaciones] h 
        ON (c.id_habitacion = h.id_habitacion) 
    JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[consumibles] co 
        ON (co.id_consumible = c.id_consumible)
    WHERE id_estadia = @id_estadia
END

GO

-- Este procedure se utiliza para actualizar un consumo
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[MODIFICAR_CONSUMO]
    (@id_rol_user INT, @id_consumo INT, @id_consumible INT, @id_habitacion INT, 
    @fecha_consumo DATETIME, @cantidad_consumo INT)
AS
BEGIN
    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO] @id_rol_user, 23

    UPDATE [EL_MONSTRUO_DEL_LAGO_MASER].[consumos]
    SET id_consumible = @id_consumible, id_habitacion = @id_habitacion, 
        fecha_consumo = @fecha_consumo, cantidad_consumo = @cantidad_consumo
    WHERE id_consumo = @id_consumo 
END

GO

-- Este procedure elimina un consumo
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[BORRAR_CONSUMO]
    (@id_rol_user INT, @id_consumo INT)
AS
BEGIN
    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO] @id_rol_user, 23

    DELETE FROM [EL_MONSTRUO_DEL_LAGO_MASER].[consumos]
    WHERE id_consumo = @id_consumo
END

GO

-- Este procedure cierra los consumos de una estadìa (ya no se va a poder ingresar mas consumos ni modificarlos)
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[CERRAR_CONSUMO_ESTADIA](@id_rol_user INT, @id_estadia INT)
AS
BEGIN
    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO] @id_rol_user, 23

    UPDATE [EL_MONSTRUO_DEL_LAGO_MASER].[estadias]
    SET consumos_cerrados = 1
    WHERE id_estadia = @id_estadia
END

GO

-- Este procedure obtiene los datos para iniciar el proceso de facturación
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_DATOS_ESTADIA_FACTURACION]
    (@id_estadia INT)
AS
BEGIN
    SELECT fecha_ingreso_estadia, fecha_egreso_estadia, 
    fecha_inicio_reserva, fecha_fin_reserva, id_regimen
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[estadias] e
    JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[reservas] r
        ON (e.id_reserva = r.id_reserva)
    WHERE id_estadia = @id_estadia
    AND consumos_cerrados = 1
    AND fecha_egreso_estadia IS NOT NULL
    AND id_estadia NOT IN (SELECT DISTINCT id_estadia
                           FROM [EL_MONSTRUO_DEL_LAGO_MASER].[facturas])
END

GO

-- Funcion que obtiene el costo diario de una estadia
CREATE FUNCTION [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_COSTO_DIARIO_ESTADIA]
(@id_estadia INT)
RETURNS NUMERIC(18,2)
AS
BEGIN
    DECLARE @costo NUMERIC(18,2)
    SELECT @costo = SUM((precio_base_regimen * cantidad_huespedes_tipo_habitacion * (1 + (porcentual_tipo_habitacion/100))) +
           (cantidad_estrellas_hotel * recarga_por_estrellas_hotel))
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[estadias] e
    JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[reservas] r
        ON e.id_reserva = r.id_reserva
    JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[regimenes] rr
        ON r.id_regimen = rr.id_regimen
    JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[reservasXhabitaciones] rxh
        ON r.id_reserva = rxh.id_reserva
    JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[habitaciones] h
        ON rxh.id_habitacion = h.id_habitacion
    JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[tipos_habitacion] th
        ON h.id_tipo_habitacion = th.id_tipo_habitacion
    JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[hoteles] hh
        ON h.id_hotel = hh.id_hotel
    WHERE id_estadia = @id_estadia

    RETURN @costo
END

GO

-- Este procedure obtiene el costo diario de una estadia/reserva
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[CALCULAR_COSTO_DIARIO_ESTADIA]
    (@id_estadia INT)
AS
BEGIN
    SELECT EL_MONSTRUO_DEL_LAGO_MASER.OBTENER_COSTO_DIARIO_ESTADIA(@id_estadia)
END

GO

-- Obtengo el ID del regimen all inclusive moderado
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_REGIMEN_ALL_INCLUSIVE_MODERADO]
AS
BEGIN
	SELECT id_regimen
	FROM [EL_MONSTRUO_DEL_LAGO_MASER].[regimenes]
	WHERE descripcion_regimen = 'All inclusive moderado'
END

GO

-- Este procedure obtiene el regimen de estadía
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_REGIMEN_DE_ESTADIA](@id_estadia INT)
AS
BEGIN
    SELECT r.id_regimen, descripcion_regimen, precio_base_regimen, estado_regimen
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[estadias] e 
    JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[reservas] r 
        ON (e.id_reserva = r.id_reserva) 
    JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[regimenes] re 
        ON (r.id_regimen = re.id_regimen) 
    WHERE id_estadia = @id_estadia
END

GO

-- Este procedure obtiene las formas de pago
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[OBTENER_FORMAS_DE_PAGO]
AS
BEGIN
    SELECT id_forma_de_pago, descripcion_forma_de_pago
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[formas_de_pago]
END

GO

-- Type necesario para insertar facturas
CREATE TYPE [EL_MONSTRUO_DEL_LAGO_MASER].[listaDeItems] AS TABLE
    (id_consumo INT,
    precio_unitario_item_factura NUMERIC(18,2),
    descripcion_item_factura NVARCHAR(255), 
    cantidad_item_factura NUMERIC(18,0))

GO

-- Este procedure ingresa la factura con los items
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[CREAR_FACTURA]
    (@id_rol_user INT, @fecha_factura DATETIME, @total_factura NUMERIC(18,2), @id_estadia INT, @id_forma_de_pago INT, 
    @detalle_pago NVARCHAR(1000), @listaDeItems EL_MONSTRUO_DEL_LAGO_MASER.listaDeItems READONLY)
AS
BEGIN
    DECLARE @id_consumo                     INT
    DECLARE @precio_unitario_item_factura   NUMERIC(18,2)
    DECLARE @descripcion_item_factura       NVARCHAR(255)
    DECLARE @cantidad_item_factura          NUMERIC(18,0)
    DECLARE @id_factura                     INT

    DECLARE cursor_items CURSOR FOR
        SELECT id_consumo, precio_unitario_item_factura, 
            descripcion_item_factura, cantidad_item_factura
        FROM @listaDeItems

    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[VALIDAR_ROL_USUARIO] @id_rol_user, 24

    BEGIN TRY
        BEGIN TRANSACTION

        -- Primero insertamos la factura
        INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[facturas]
            (fecha_factura, total_factura, id_estadia, id_forma_de_pago, detalle_pago)
        VALUES(@fecha_factura, @total_factura, @id_estadia, @id_forma_de_pago, @detalle_pago)

        SET @id_factura = SCOPE_IDENTITY()

        -- Y luego insertamos los items de factura
        OPEN cursor_items 
        FETCH cursor_items INTO @id_consumo, 
                                @precio_unitario_item_factura, 
                                @descripcion_item_factura, 
                                @cantidad_item_factura

        WHILE (@@FETCH_STATUS = 0) BEGIN
            INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[items_factura]
                (id_factura, id_consumo, precio_unitario_item_factura, 
                descripcion_item_factura, cantidad_item_factura)
            VALUES(@id_factura, @id_consumo, @precio_unitario_item_factura, 
                @descripcion_item_factura, @cantidad_item_factura)

            FETCH cursor_items INTO @id_consumo, 
                                    @precio_unitario_item_factura, 
                                    @descripcion_item_factura, 
                                    @cantidad_item_factura
        END

        SELECT @id_factura id_factura

        COMMIT TRANSACTION
        CLOSE cursor_items 
        DEALLOCATE cursor_items 
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION

        IF CURSOR_STATUS('global', 'cursor_items') = 1 BEGIN
            CLOSE cursor_items
        END
        DEALLOCATE cursor_items;

        THROW
    END CATCH
    

END

GO

CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[TOP5_HOTELES_RESERVAS_CANCELADAS]
    (@inicio DATETIME, @fin DATETIME)
AS
BEGIN
    SELECT TOP 5 ho.id_hotel, nombre_hotel, COUNT(cr.id_cancelacion_reserva) cancelaciones
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[hoteles] ho
    LEFT JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[habitaciones] h
        ON ho.id_hotel = h.id_hotel
    LEFT JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[reservasXhabitaciones] rxh
        ON h.id_habitacion = rxh.id_habitacion
    LEFT JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[cancelaciones_reserva] cr
        ON rxh.id_reserva = cr.id_reserva
    WHERE ( fecha_cancelacion_reserva >= @inicio 
            AND fecha_cancelacion_reserva <= @fin )
    OR fecha_cancelacion_reserva IS NULL
    GROUP BY ho.id_hotel, ho.nombre_hotel
    ORDER BY COUNT(cr.id_cancelacion_reserva) DESC, nombre_hotel
END

GO

--

CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[TOP5_HOTELES_MAYOR_CANTIDAD_CONSUMOS]
    (@inicio DATETIME, @fin DATETIME)
AS
BEGIN
    SELECT TOP 5 id_hotel, nombre_hotel, SUM(cantidad_consumibles_total) cantidad_consumibles_total
    FROM (
                SELECT hot.id_hotel, nombre_hotel, ISNULL(cantidad_consumo, 0) cantidad_consumibles_total
                FROM [EL_MONSTRUO_DEL_LAGO_MASER].[consumos] c 
                RIGHT JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[habitaciones] h
                    ON (h.id_habitacion = c.id_habitacion) 
                RIGHT JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[hoteles] hot
                    ON (h.id_hotel = hot.id_hotel)
                WHERE ( fecha_consumo >= @inicio 
                        AND fecha_consumo <= @fin )
                OR (fecha_consumo IS NULL AND cantidad_consumo IS NULL)
            UNION ALL
                SELECT hot.id_hotel, nombre_hotel, 0 cantidad_consumibles_total
                FROM [EL_MONSTRUO_DEL_LAGO_MASER].[consumos] c 
                RIGHT JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[habitaciones] h
                    ON (h.id_habitacion = c.id_habitacion) 
                RIGHT JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[hoteles] hot
                    ON (h.id_hotel = hot.id_hotel)
                WHERE ( fecha_consumo >= @inicio 
                        AND fecha_consumo <= @fin )
                OR (fecha_consumo IS NULL AND cantidad_consumo IS NOT NULL)
    ) data
    GROUP BY id_hotel, nombre_hotel
    ORDER BY SUM(cantidad_consumibles_total) DESC, nombre_hotel
END

GO

-- Esta funcion devuelve la fecha mayor entre dos fechas
CREATE FUNCTION [EL_MONSTRUO_DEL_LAGO_MASER].[MAXDATE] (
    @date1        DATETIME,
    @date2        DATETIME
) RETURNS DATETIME AS
BEGIN
    DECLARE @date DATETIME;

    IF (@date1 IS NULL) OR (@date2 IS NULL)
        SET @date = NULL;

    IF (@date1 > @date2)
        SET @date = @date1;
    ELSE
        SET @date = @date2;

    RETURN @date;
END

GO

-- Esta funcion devuelve la fecha menor entre dos fechas
CREATE FUNCTION [EL_MONSTRUO_DEL_LAGO_MASER].[MINDATE] (
    @date1        DATETIME,
    @date2        DATETIME
) RETURNS DATETIME AS
BEGIN
    DECLARE @date DATETIME;

    IF (@date1 IS NULL) OR (@date2 IS NULL)
        SET @date = NULL;

    IF (@date1 < @date2)
        SET @date = @date1;
    ELSE
        SET @date = @date2;

    RETURN @date;
END

GO

--

CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[TOP5_HOTELES_DIAS_CERRADO]
    (@inicio DATETIME, @fin DATETIME)
AS
BEGIN
    SELECT TOP 5 id_hotel, nombre_hotel, SUM(dias_cerrado) dias_cerrado
    FROM (
        -- Generamos todos los hoteles primero
            SELECT id_hotel, nombre_hotel, 0 dias_cerrado
            FROM [EL_MONSTRUO_DEL_LAGO_MASER].[hoteles]
        UNION ALL
        -- Obtenemos la suma de dias reservados
            SELECT h.id_hotel, nombre_hotel, DATEDIFF(day, EL_MONSTRUO_DEL_LAGO_MASER.MAXDATE(@inicio, fecha_inicio_cierre_temporal_hotel),
                EL_MONSTRUO_DEL_LAGO_MASER.MINDATE(@fin, fecha_fin_cierre_temporal_hotel)) + 1 dias_cerrado
            FROM [EL_MONSTRUO_DEL_LAGO_MASER].[hoteles] h
            JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[cierres_temporales_hotel] c
                ON h.id_hotel = c.id_hotel
            WHERE ((@inicio <= fecha_fin_cierre_temporal_hotel)
            AND (fecha_inicio_cierre_temporal_hotel <= @fin))
        ) data
    GROUP BY id_hotel, nombre_hotel
    ORDER BY dias_cerrado DESC, nombre_hotel
END

GO

--

CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[TOP5_HABITACIONES_MAYOR_CANTIDAD_DIAS_ESTADIAS]
    (@inicio DATETIME, @fin DATETIME, @fechaHoy DATETIME)
AS
BEGIN
    SELECT TOP 5 id_habitacion, id_hotel, nombre_hotel, numero_habitacion, 
        SUM(cantidad_dias) cantidad_dias, SUM(cantidad_estadias) cantidad_estadias
    FROM (
                -- Generamos todas las habitaciones
                SELECT DISTINCT ha.id_habitacion, ha.id_hotel, nombre_hotel, numero_habitacion, 0 cantidad_dias, 0 cantidad_estadias
                FROM [EL_MONSTRUO_DEL_LAGO_MASER].[habitaciones] ha
                INNER JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[hoteles] ho
                    ON ha.id_hotel = ho.id_hotel
                LEFT JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[reservasXhabitaciones] rh
                    ON ha.id_habitacion = rh.id_habitacion
                LEFT JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[estadias] e
                    ON rh.id_reserva = e.id_reserva
            UNION ALL
                -- Ahora los que tienen finalizada la estadía (no importa el día de hoy)
                SELECT ha.id_habitacion, ha.id_hotel, nombre_hotel, numero_habitacion, 
                    ISNULL(SUM(DATEDIFF(day, EL_MONSTRUO_DEL_LAGO_MASER.MAXDATE(@inicio, fecha_ingreso_estadia),
                    EL_MONSTRUO_DEL_LAGO_MASER.MINDATE(@fin, fecha_egreso_estadia))), 0) cantidad_dias, COUNT(DISTINCT id_estadia) cantidad_estadias
                FROM [EL_MONSTRUO_DEL_LAGO_MASER].[habitaciones] ha
                INNER JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[hoteles] ho
                    ON ha.id_hotel = ho.id_hotel
                INNER JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[reservasXhabitaciones] rh
                    ON ha.id_habitacion = rh.id_habitacion
                INNER JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[estadias] e
                    ON rh.id_reserva = e.id_reserva
                WHERE fecha_egreso_estadia IS NOT NULL
                AND ((@inicio <= fecha_egreso_estadia)
                AND (fecha_ingreso_estadia <= @fin))
                GROUP BY ha.id_habitacion, ha.id_hotel, nombre_hotel, numero_habitacion
            UNION ALL
                -- Ahora los que están en curso (fecha de fin sería la fecha de hoy)
                SELECT ha.id_habitacion, ha.id_hotel, nombre_hotel, numero_habitacion, 
                    ISNULL(SUM(DATEDIFF(day, EL_MONSTRUO_DEL_LAGO_MASER.MAXDATE(@inicio, fecha_ingreso_estadia),
                    EL_MONSTRUO_DEL_LAGO_MASER.MINDATE(@fin, @fechaHoy))), 0) cantidad_dias, COUNT(DISTINCT id_estadia) cantidad_estadias
                FROM [EL_MONSTRUO_DEL_LAGO_MASER].[habitaciones] ha
                INNER JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[hoteles] ho
                    ON ha.id_hotel = ho.id_hotel
                INNER JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[reservasXhabitaciones] rh
                    ON ha.id_habitacion = rh.id_habitacion
                INNER JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[estadias] e
                    ON rh.id_reserva = e.id_reserva
                WHERE fecha_egreso_estadia IS NULL
                AND ((@inicio <= @fechaHoy)
                AND (fecha_ingreso_estadia <= @fin))
                GROUP BY ha.id_habitacion, ha.id_hotel, nombre_hotel, numero_habitacion
        ) data
    GROUP BY id_habitacion, id_hotel, nombre_hotel, numero_habitacion
    ORDER BY cantidad_dias DESC, nombre_hotel
END

GO

--

CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[TOP5_CLIENTES_PUNTOS]
    (@inicio DATETIME, @fin DATETIME, @fechaHoy DATETIME)
AS
BEGIN
    SELECT TOP 5 nombre_cliente, apellido_cliente, correo_cliente, SUM(puntos) puntos
    FROM (
            ---- Generamos los clientes
                SELECT id_cliente, nombre_cliente, apellido_cliente, correo_cliente, 0 puntos
                FROM [EL_MONSTRUO_DEL_LAGO_MASER].[clientes]
            -- Ahora unimos los consumos de los clientes
            UNION ALL
                SELECT cl.id_cliente, nombre_cliente, apellido_cliente, correo_cliente, (precio_consumible * cantidad_consumo)/10 puntos
                FROM [EL_MONSTRUO_DEL_LAGO_MASER].[consumos] c
                JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[consumibles] co
                    ON c.id_consumible = co.id_consumible
                JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[estadias] e
                    ON c.id_estadia = e.id_estadia
                JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[reservas] r
                    ON e.id_reserva = r.id_reserva
                JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[clientes] cl
                    ON r.id_cliente = cl.id_cliente
                WHERE fecha_consumo >= @inicio
                AND fecha_consumo <= @fin
            -- Ahora unimos las estadías COMPLETAS
            UNION ALL
                SELECT c.id_cliente, nombre_cliente, apellido_cliente, correo_cliente, 
                    (DATEDIFF(day,  EL_MONSTRUO_DEL_LAGO_MASER.MAXDATE(fecha_ingreso_estadia, @inicio), 
                                    EL_MONSTRUO_DEL_LAGO_MASER.MINDATE(fecha_egreso_estadia, @fin)) * 
                    EL_MONSTRUO_DEL_LAGO_MASER.OBTENER_COSTO_DIARIO_ESTADIA(id_estadia))/20 puntos
                FROM [EL_MONSTRUO_DEL_LAGO_MASER].[estadias] e
                JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[reservas] r
                    ON e.id_reserva = r.id_reserva
                JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[clientes] c
                    ON r.id_cliente = c.id_cliente
                WHERE ((@inicio <= fecha_egreso_estadia)
                    AND (fecha_ingreso_estadia <= @fin))
            -- Y finalmente las estadías pendientes
            UNION ALL
                SELECT c.id_cliente, nombre_cliente, apellido_cliente, correo_cliente,
                    (DATEDIFF(day,  EL_MONSTRUO_DEL_LAGO_MASER.MAXDATE(fecha_ingreso_estadia, @inicio), 
                                    EL_MONSTRUO_DEL_LAGO_MASER.MINDATE(@fechaHoy, @fin)) * 
                    EL_MONSTRUO_DEL_LAGO_MASER.OBTENER_COSTO_DIARIO_ESTADIA(id_estadia))/20 puntos
                FROM [EL_MONSTRUO_DEL_LAGO_MASER].[estadias] e
                JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[reservas] r
                    ON e.id_reserva = r.id_reserva
                JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[clientes] c
                    ON r.id_cliente = c.id_cliente
                WHERE fecha_egreso_estadia IS NULL
                AND ((@inicio <= @fechaHoy)
                AND (fecha_ingreso_estadia <= @fin))
                AND @fechaHoy >= fecha_ingreso_estadia
        ) data
    WHERE id_cliente <> 0
    GROUP BY nombre_cliente, apellido_cliente, correo_cliente
    ORDER BY puntos DESC, nombre_cliente, apellido_cliente
END

GO

-- Procedimiento que crea los tipos de habitación con IDENTITY (respetando los valores recibidos)
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[CREAR_TIPOS_HABITACION] AS
BEGIN
    INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[tipos_habitacion]
    SELECT descripcion, porcentual, cantidad
    FROM (
            SELECT DISTINCT 
                    Habitacion_Tipo_Codigo codigo,
                    Habitacion_Tipo_Descripcion descripcion,
                    Habitacion_Tipo_Porcentual porcentual,
                    cantidad = CASE Habitacion_Tipo_Descripcion
                        WHEN 'Base Simple'    THEN 1
                        WHEN 'Base Doble'     THEN 2
                        WHEN 'Base Triple'    THEN 3
                        WHEN 'Base Cuadruple' THEN 4
                        WHEN 'King'           THEN 5
                        ELSE -1
                    END
            FROM [gd_esquema].[Maestra]
         ) tipos 
    ORDER BY codigo ASC;
END
GO

-- Procedimiento que crea las reservas con IDENTITY (respetando los valores recibidos)
-- Requiere editar el cliente y el regimen a posteriori de la ejecución
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[CREAR_RESERVAS] AS
BEGIN
    INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[reservas]
    SELECT convert(datetime, '20010101', 112), inicio, inicio + noches, 0, -1, 7
    FROM (
            SELECT DISTINCT Reserva_Codigo codigo, Reserva_Fecha_Inicio inicio, Reserva_Cant_Noches noches
            FROM [gd_esquema].[Maestra]
         ) reservas
    ORDER BY codigo
END
GO

-- Procedimiento que crea los consumibles con IDENTITY (respetando los valores recibidos)
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[CREAR_CONSUMIBLES] AS
BEGIN
    INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[consumibles]
    SELECT precio, descripcion
    FROM (
            SELECT DISTINCT Consumible_Codigo codigo, Consumible_Descripcion descripcion, Consumible_Precio precio
            FROM [gd_esquema].[Maestra]
         ) consumibles
    WHERE codigo IS NOT NULL
    ORDER BY codigo
END
GO

-- Procedimiento que crea las facturas con IDENTITY (respetando los valores recibidos)
-- Requiere editar la estadía a posteriori de la ejecución
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[CREAR_FACTURAS] AS
BEGIN
    INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[facturas]
    SELECT fecha, total, -1, 13, ''
    FROM (
            SELECT DISTINCT Factura_Nro numero, Factura_Fecha fecha, Factura_Total total
            FROM [gd_esquema].[Maestra]
         ) facturas
    WHERE numero IS NOT NULL
    ORDER BY numero
END
GO

-- Procedure principal de la migración
CREATE PROCEDURE [EL_MONSTRUO_DEL_LAGO_MASER].[MIGRAR_DATOS] AS
BEGIN
    -- Ejecuciones previas
    -- Debido a que necesitamos que se inserten respetando el orden de código
    -- (porque lo hicimos con IDENTITY), los ejecutamos por separado
    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[CREAR_TIPOS_HABITACION];
    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[CREAR_RESERVAS];
    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[CREAR_CONSUMIBLES];
    EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[CREAR_FACTURAS];

    SELECT CAST(NULL as INT)                          id_hotel,
           Hotel_Ciudad                               ciudad_hotel,
           Hotel_Calle                                domicilio_calle_hotel,
           Hotel_Nro_Calle                            domicilio_numero_hotel,
           Hotel_CantEstrella                         cantidad_estrellas_hotel,
           Hotel_Recarga_Estrella                     recarga_por_estrellas_hotel,
           CAST(NULL as INT)                          id_habitacion,
           Habitacion_Numero                          numero_habitacion,
           Habitacion_Piso                            piso_habitacion,
           Habitacion_Frente                          ubicacion_habitacion,
           Habitacion_Tipo_Codigo                     id_tipo_habitacion,
           CAST(NULL as INT)                          id_regimen,
           Regimen_Descripcion                        descripcion_regimen,
           Regimen_Precio                             precio_base_regimen,
           Reserva_Codigo                             id_reserva,
           CAST(NULL as INT)                          id_estadia,
           Estadia_Fecha_Inicio                       fecha_ingreso_estadia,
           Estadia_Fecha_Inicio + Estadia_Cant_Noches fecha_egreso_estadia,
           Consumible_Codigo                          id_consumible,
           CAST(NULL as INT)                          id_consumo,
           CAST(NULL as INT)                          id_item_factura,
           Item_Factura_Cantidad                      cantidad_item_factura,
           Item_Factura_Monto                         precio_unitario_item_factura,
           Factura_Nro                                id_factura,
           CAST(NULL as INT)                          id_cliente,
           Cliente_Pasaporte_Nro                      numero_documento_cliente,
           Cliente_Apellido                           apellido_cliente,
           Cliente_Nombre                             nombre_cliente,
           Cliente_Fecha_Nac                          fecha_nacimiento_cliente,
           Cliente_Mail                               correo_cliente,
           Cliente_Dom_Calle                          domicilio_calle_cliente,
           Cliente_Nro_Calle                          domicilio_numero_cliente,
           Cliente_Piso                               domicilio_piso_cliente,
           Cliente_Depto                              domicilio_departamento_cliente,
           Cliente_Nacionalidad                       nacionalidad_cliente
    INTO #master
    FROM [gd_esquema].[Maestra]
    
    -- Necesitamos esta secuencia para los consumos (que no son distinct)
    CREATE SEQUENCE [EL_MONSTRUO_DEL_LAGO_MASER].[secuencia_consumos]
    AS INT
    START WITH 1
    INCREMENT BY 1
    
    -- Y esta para los items de factura
    CREATE SEQUENCE [EL_MONSTRUO_DEL_LAGO_MASER].[secuencia_items_factura]
    AS INT
    START WITH 1
    INCREMENT BY 1
    
    UPDATE #master
    SET id_consumo = NEXT VALUE FOR [EL_MONSTRUO_DEL_LAGO_MASER].[secuencia_consumos]
    WHERE id_consumible IS NOT NULL
    AND   fecha_ingreso_estadia IS NOT NULL
    
    UPDATE #master
    SET id_item_factura = NEXT VALUE FOR [EL_MONSTRUO_DEL_LAGO_MASER].[secuencia_items_factura]
    WHERE id_factura IS NOT NULL
    
    DROP SEQUENCE [EL_MONSTRUO_DEL_LAGO_MASER].[secuencia_consumos]
    DROP SEQUENCE [EL_MONSTRUO_DEL_LAGO_MASER].[secuencia_items_factura]
    
    ------------------------------------------------ HOTELES ------------------------------------------------
    INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[hoteles]
        (ciudad_hotel, domicilio_calle_hotel, domicilio_numero_hotel, cantidad_estrellas_hotel, recarga_por_estrellas_hotel)
    SELECT DISTINCT ciudad_hotel, domicilio_calle_hotel, domicilio_numero_hotel, cantidad_estrellas_hotel, recarga_por_estrellas_hotel
    FROM #master
    
    -- Seteamos el id_hotel en la tabla temporal para seguir con el procesamiento
    UPDATE #master
    SET id_hotel = h.id_hotel
    FROM #master temp
    JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[hoteles] h
    ON  h.ciudad_hotel = temp.ciudad_hotel
    AND h.domicilio_calle_hotel = temp.domicilio_calle_hotel
    AND h.domicilio_numero_hotel = temp.domicilio_numero_hotel
    AND h.cantidad_estrellas_hotel = temp.cantidad_estrellas_hotel
    AND h.recarga_por_estrellas_hotel = temp.recarga_por_estrellas_hotel
    
    -- Limpiamos las columnas que no necesitamos más
    ALTER TABLE #master
    DROP COLUMN ciudad_hotel, domicilio_calle_hotel, domicilio_numero_hotel, cantidad_estrellas_hotel, recarga_por_estrellas_hotel
    ------------------------------------------------ HOTELES ------------------------------------------------
    ---------------------------------------------- HABITACIONES ---------------------------------------------
    INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[habitaciones]
        (id_hotel, numero_habitacion, piso_habitacion, ubicacion_habitacion, id_tipo_habitacion)
    SELECT DISTINCT id_hotel, numero_habitacion, piso_habitacion, ubicacion_habitacion, id_tipo_habitacion
    FROM #master
    
    -- Seteamos el id_habitacion para seguir el procesamiento
    UPDATE #master
    SET id_habitacion = h.id_habitacion
    FROM #master temp
    JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[habitaciones] h
    ON  h.id_hotel = temp.id_hotel
    AND h.numero_habitacion = temp.numero_habitacion
    AND h.piso_habitacion = temp.piso_habitacion
    AND h.ubicacion_habitacion = temp.ubicacion_habitacion
    AND h.id_tipo_habitacion = temp.id_tipo_habitacion
    
    -- Insertamos a la relación muchos a muchos entre reservas y habitaciones
    INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[reservasXhabitaciones]
        (id_reserva, id_habitacion)
    SELECT DISTINCT id_reserva, id_habitacion
    FROM #master
    
    -- Limpiamos las columnas que no necesitamos más
    ALTER TABLE #master
    DROP COLUMN numero_habitacion, piso_habitacion, ubicacion_habitacion, id_tipo_habitacion
    ---------------------------------------------- HABITACIONES ---------------------------------------------
    ----------------------------------------------- REGIMENES -----------------------------------------------
    INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[regimenes]
        (descripcion_regimen, precio_base_regimen)
    SELECT DISTINCT descripcion_regimen, precio_base_regimen
    FROM #master
    
    -- Seteamos el id_regimen para seguir el procesamiento
    UPDATE #master
    SET id_regimen = r.id_regimen
    FROM #master temp
    JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[regimenes] r
    ON  r.descripcion_regimen = temp.descripcion_regimen
    AND r.precio_base_regimen = temp.precio_base_regimen
    
    -- Insertamos a la relación muchos a muchos entre hoteles y regimenes
    INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[hotelesXregimenes]
        (id_hotel, id_regimen)
    SELECT DISTINCT id_hotel, id_regimen
    FROM #master
    
    -- Updateamos en reservas el regimen usado
    UPDATE [EL_MONSTRUO_DEL_LAGO_MASER].[reservas]
        SET id_regimen = temp.id_regimen
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[reservas] r
    JOIN #master temp
        ON r.id_reserva = temp.id_reserva
    
    -- Limpiamos las columnas que no necesitamos más
    ALTER TABLE #master
    DROP COLUMN descripcion_regimen, precio_base_regimen, id_hotel, id_regimen
    ----------------------------------------------- REGIMENES -----------------------------------------------
    -----------------------------------------------  ESTADIAS -----------------------------------------------
    INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[estadias]
        (id_reserva, id_usuario_ingreso, id_usuario_egreso, fecha_ingreso_estadia, fecha_egreso_estadia)
    SELECT DISTINCT id_reserva, 1, 1, fecha_ingreso_estadia, fecha_egreso_estadia
    FROM #master
    WHERE fecha_ingreso_estadia IS NOT NULL
    
    -- Seteamos el id_estadia para seguir el procesamiento
    UPDATE #master
    SET id_estadia = e.id_estadia
    FROM #master temp
    JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[estadias] e
    ON  e.id_reserva = temp.id_reserva
    AND e.fecha_ingreso_estadia = temp.fecha_ingreso_estadia
    AND e.fecha_egreso_estadia = temp.fecha_egreso_estadia
    
    -- Updateamos en facturas la estadía
    UPDATE [EL_MONSTRUO_DEL_LAGO_MASER].[facturas]
        SET id_estadia = temp.id_estadia
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[facturas] f
    JOIN #master temp
        ON f.id_factura = temp.id_factura
    
    -- Limpiamos las columnas que no necesitamos más
    ALTER TABLE #master
    DROP COLUMN fecha_ingreso_estadia, fecha_egreso_estadia
    -----------------------------------------------  ESTADIAS -----------------------------------------------
    -----------------------------------------------  CONSUMOS -----------------------------------------------
    INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[consumos]
        (id_consumible, id_estadia, id_habitacion, cantidad_consumo)
    SELECT id_consumible, id_estadia, id_habitacion, cantidad_item_factura 
    FROM #master
    WHERE id_consumo IS NOT NULL
    ORDER BY id_consumo
    
    -- Limpiamos las columnas que no necesitamos más
    ALTER TABLE #master
    DROP COLUMN id_consumible, id_habitacion
    -----------------------------------------------  CONSUMOS -----------------------------------------------
    ---------------------------------------------  ITEMS FACTURA --------------------------------------------
    INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[items_factura]
        (id_factura, id_consumo, precio_unitario_item_factura, cantidad_item_factura)
    SELECT id_factura, id_consumo, precio_unitario_item_factura, cantidad_item_factura
    FROM #master
    WHERE id_item_factura IS NOT NULL
    
    -- Limpiamos las columnas que no necesitamos más
    ALTER TABLE #master
    DROP COLUMN id_consumo, id_item_factura, cantidad_item_factura, precio_unitario_item_factura, id_factura
    ---------------------------------------------  ITEMS FACTURA --------------------------------------------
    -----------------------------------------------  CLIENTES -----------------------------------------------
    CREATE TABLE #clientes_premigracion (
        nombre_cliente NVARCHAR(255),
        apellido_cliente NVARCHAR(255),
        numero_documento_cliente NUMERIC(18, 0),
        correo_cliente NVARCHAR(255),
        domicilio_calle_cliente NVARCHAR(255),
        domicilio_numero_cliente NUMERIC(18, 0),
        domicilio_piso_cliente NUMERIC(18, 0),
        domicilio_departamento_cliente NVARCHAR(50),
        nacionalidad_cliente NVARCHAR(20),
        fecha_nacimiento_cliente DATETIME
    )
    
    -- Creamos una tabla temporal con unique indexes que no exploten al hacer bulk insert
    CREATE UNIQUE INDEX temp_clientes_numero_documento
    ON #clientes_premigracion(numero_documento_cliente)
    WITH IGNORE_DUP_KEY
    
    CREATE UNIQUE INDEX temp_clientes_correo
    ON #clientes_premigracion(correo_cliente)
    WITH IGNORE_DUP_KEY
    
    -- Poblamos la tabla
    INSERT INTO #clientes_premigracion
    SELECT DISTINCT nombre_cliente, apellido_cliente, numero_documento_cliente, correo_cliente, domicilio_calle_cliente,
        domicilio_numero_cliente, domicilio_piso_cliente, domicilio_departamento_cliente, nacionalidad_cliente, fecha_nacimiento_cliente
    FROM #master
    
    -- Insertamos los clientes
    INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[clientes]
        (nombre_cliente, apellido_cliente, numero_documento_cliente, correo_cliente, domicilio_calle_cliente,
        domicilio_numero_cliente, domicilio_piso_cliente, domicilio_departamento_cliente, nacionalidad_cliente, fecha_nacimiento_cliente)
    SELECT nombre_cliente, apellido_cliente, numero_documento_cliente, correo_cliente, domicilio_calle_cliente,
        domicilio_numero_cliente, domicilio_piso_cliente, domicilio_departamento_cliente, nacionalidad_cliente, fecha_nacimiento_cliente 
    FROM #clientes_premigracion
    
    -- Borramos la tabla temporal
    DROP TABLE #clientes_premigracion
    
    -- Seteamos el id_cliente para seguir el procesamiento
    UPDATE #master
    SET id_cliente = c.id_cliente
    FROM #master temp
    JOIN [EL_MONSTRUO_DEL_LAGO_MASER].[clientes] c
    ON  c.nombre_cliente = temp.nombre_cliente
    AND c.apellido_cliente = temp.apellido_cliente 
    AND c.numero_documento_cliente = temp.numero_documento_cliente
    AND c.correo_cliente = temp.correo_cliente
    AND c.domicilio_calle_cliente = temp.domicilio_calle_cliente
    AND c.domicilio_numero_cliente = temp.domicilio_numero_cliente
    AND c.domicilio_piso_cliente = temp.domicilio_piso_cliente
    AND c.domicilio_departamento_cliente = temp.domicilio_departamento_cliente
    AND c.nacionalidad_cliente = temp.nacionalidad_cliente
    AND c.fecha_nacimiento_cliente = temp.fecha_nacimiento_cliente 
    
    -- Insertamos a la relación muchos a muchos entre clientes y estadias
    INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[clientesXestadias]
    SELECT DISTINCT id_cliente, id_estadia
    FROM #master
    WHERE id_estadia IS NOT NULL
    AND   id_cliente IS NOT NULL
    
    -- Updateamos en reservas al cliente
    UPDATE [EL_MONSTRUO_DEL_LAGO_MASER].[reservas]
        SET id_cliente = temp.id_cliente
    FROM [EL_MONSTRUO_DEL_LAGO_MASER].[reservas] r
    JOIN #master temp
        ON r.id_reserva = temp.id_reserva
    WHERE temp.id_cliente IS NOT NULL
    -----------------------------------------------  CLIENTES -----------------------------------------------
    -- Preparamos la tabla de errores de migración con los datos restantes.
    INSERT INTO [EL_MONSTRUO_DEL_LAGO_MASER].[migracion_errores]
    SELECT *
    FROM #master
    WHERE id_cliente IS NULL
    
    DROP TABLE #master

END

GO

EXEC [EL_MONSTRUO_DEL_LAGO_MASER].[MIGRAR_DATOS]

GO

-- Si ya está facturado, es porque ya cerro los consumos.
UPDATE [EL_MONSTRUO_DEL_LAGO_MASER].[estadias]
SET consumos_cerrados = 1
WHERE id_estadia IN (SELECT DISTINCT id_estadia 
                     FROM [EL_MONSTRUO_DEL_LAGO_MASER].[facturas])
UPDATE [EL_MONSTRUO_DEL_LAGO_MASER].[hoteles]
SET nombre_hotel = nombre_hotel + ' ' + CAST(id_hotel AS NVARCHAR)

GO
-- Indices de cliente
CREATE INDEX index_cliente_nombre ON [EL_MONSTRUO_DEL_LAGO_MASER].[clientes] (nombre_cliente)
CREATE INDEX index_cliente_apellido ON [EL_MONSTRUO_DEL_LAGO_MASER].[clientes] (apellido_cliente)

-- Indices de reservas
CREATE INDEX index_fecha_inicio_reserva ON [EL_MONSTRUO_DEL_LAGO_MASER].[reservas] (fecha_inicio_reserva)
CREATE INDEX index_fecha_inicio_fin_reserva ON [EL_MONSTRUO_DEL_LAGO_MASER].[reservas] (fecha_inicio_reserva, fecha_fin_reserva)

GO
ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[clientes]
ADD FOREIGN KEY (id_tipo_documento) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[tipos_documento](id_tipo_documento);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[clientes]
ADD FOREIGN KEY (id_pais) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[paises](id_pais);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[cuentas]
ADD FOREIGN KEY (id_usuario) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[usuarios](id_usuario);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[facturas]
ADD FOREIGN KEY (id_estadia) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[estadias](id_estadia);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[facturas]
ADD FOREIGN KEY (id_forma_de_pago) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[formas_de_pago](id_forma_de_pago);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[consumos]
ADD FOREIGN KEY (id_consumible) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[consumibles](id_consumible);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[consumos]
ADD FOREIGN KEY (id_estadia) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[estadias](id_estadia);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[consumos]
ADD FOREIGN KEY (id_habitacion) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[habitaciones](id_habitacion);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[clientesXestadias]
ADD FOREIGN KEY (id_cliente) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[clientes](id_cliente);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[clientesXestadias]
ADD FOREIGN KEY (id_estadia) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[estadias](id_estadia);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[cierres_temporales_habitacion]
ADD FOREIGN KEY (id_habitacion) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[habitaciones](id_habitacion);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[items_factura]
ADD FOREIGN KEY (id_factura) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[facturas](id_factura);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[items_factura]
ADD FOREIGN KEY (id_consumo) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[consumos](id_consumo);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[estadias]
ADD FOREIGN KEY (id_reserva) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[reservas](id_reserva);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[estadias]
ADD FOREIGN KEY (id_usuario_ingreso) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[usuarios](id_usuario);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[estadias]
ADD FOREIGN KEY (id_usuario_egreso) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[usuarios](id_usuario);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[habitaciones]
ADD FOREIGN KEY (id_hotel) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[hoteles](id_hotel);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[habitaciones]
ADD FOREIGN KEY (id_tipo_habitacion) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[tipos_habitacion](id_tipo_habitacion);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[reservasXhabitaciones]
ADD FOREIGN KEY (id_reserva) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[reservas](id_reserva);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[reservasXhabitaciones]
ADD FOREIGN KEY (id_habitacion) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[habitaciones](id_habitacion);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[usuariosXroles]
ADD FOREIGN KEY (id_rol) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[roles](id_rol);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[usuariosXroles]
ADD FOREIGN KEY (id_usuario) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[usuarios](id_usuario);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[cancelaciones_reserva]
ADD FOREIGN KEY (id_reserva) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[reservas](id_reserva);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[cancelaciones_reserva]
ADD FOREIGN KEY (id_usuario) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[usuarios](id_usuario);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[reservas]
ADD FOREIGN KEY (id_cliente) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[clientes](id_cliente);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[reservas]
ADD FOREIGN KEY (id_regimen) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[regimenes](id_regimen);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[reservas]
ADD FOREIGN KEY (id_estado_reserva) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[estados_reserva](id_estado_reserva);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[usuariosXhoteles]
ADD FOREIGN KEY (id_usuario) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[usuarios](id_usuario);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[usuariosXhoteles]
ADD FOREIGN KEY (id_hotel) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[hoteles](id_hotel);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[hotelesXregimenes]
ADD FOREIGN KEY (id_hotel) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[hoteles](id_hotel);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[hotelesXregimenes]
ADD FOREIGN KEY (id_regimen) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[regimenes](id_regimen);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[hoteles]
ADD FOREIGN KEY (id_pais) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[paises](id_pais);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades]
ADD FOREIGN KEY (id_rol) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[roles](id_rol);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[rolesXfuncionalidades]
ADD FOREIGN KEY (id_funcionalidad) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[funcionalidades](id_funcionalidad);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[cierres_temporales_hotel]
ADD FOREIGN KEY (id_hotel) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[hoteles](id_hotel);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[generacion_modificacion_reservas]
ADD FOREIGN KEY (id_reserva) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[reservas](id_reserva);

ALTER TABLE [EL_MONSTRUO_DEL_LAGO_MASER].[generacion_modificacion_reservas]
ADD FOREIGN KEY (id_usuario) REFERENCES [EL_MONSTRUO_DEL_LAGO_MASER].[usuarios](id_usuario);

