Curso: K3013
Número de grupo: 15

Integrantes:
    BESTEIRO FERNANDO MARTÍN - 1558973
    PERRONE GUILLERMO        - 1572751
    LAGO AGUSTÍN JAVIER      - 1388782
    DE LA CRUZ ÁLVARO        - 1593730

Email del responsable:
    fmbesteiro@gmail.com